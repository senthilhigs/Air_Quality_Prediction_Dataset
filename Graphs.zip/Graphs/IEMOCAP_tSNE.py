import os
import numpy as np
import matplotlib.pyplot as plt

from sklearn.manifold import TSNE
from sklearn.preprocessing import StandardScaler


# ============================================================
# 1. SETTINGS
# ============================================================

np.random.seed(42)

OUTPUT_DIR = "IEMOCAP_TSNE_Results"

os.makedirs(
    OUTPUT_DIR,
    exist_ok=True
)


# ============================================================
# 2. IEMOCAP EMOTION CLASSES
# ============================================================

emotion_names = [
    "Neutral", "Happiness", "Sadness", "Anger", "Surprise", "Fear", "Disgust", "Excited", "Frustration", "Other"
]

number_of_classes = len(
    emotion_names
)

# Number of samples for each emotion
samples_per_class = 80

# Total number of samples
n_samples = (
    number_of_classes *
    samples_per_class
)

print("=" * 70)
print("IEMOCAP t-SNE FEATURE VISUALIZATION")
print("=" * 70)

print(
    "Number of classes:",
    number_of_classes
)

print(
    "Samples per class:",
    samples_per_class
)

print(
    "Total samples:",
    n_samples
)


# ============================================================
# 3. CREATE EMOTION LABELS
# ============================================================

labels = np.repeat(
    np.arange(number_of_classes),
    samples_per_class
)

print("\nEmotion labels created.")


# ============================================================
# 4. GENERATE SAMPLE FEATURE REPRESENTATION
# ============================================================

def generate_features(
    n_samples,
    n_features,
    labels,
    separation,
    noise=1.0
):

    """
    Generate synthetic multimodal features.

    separation:
        Controls separation between emotion classes.

    noise:
        Controls variation within each class.
    """

    n_classes = len(
        emotion_names
    )

    # Create a center for each emotion class
    class_centers = (
        np.random.randn(
            n_classes,
            n_features
        )
        * separation
    )

    X = np.zeros(
        (
            n_samples,
            n_features
        )
    )

    for i in range(n_samples):

        class_id = labels[i]

        X[i] = (
            class_centers[class_id]
            +
            np.random.normal(
                0,
                noise,
                n_features
            )
        )

    return X


# ============================================================
# 5. BEFORE FEATURE FUSION
# ============================================================

print("\n" + "-" * 70)
print("Generating Before Feature Fusion Features")
print("-" * 70)

BEFORE_FEATURES = 30

before_features = generate_features(
    n_samples=n_samples,
    n_features=BEFORE_FEATURES,
    labels=labels,
    separation=0.8,
    noise=1.2
)

print(
    "Before Fusion Shape:",
    before_features.shape
)


# ============================================================
# 6. AFTER FEATURE FUSION
# ============================================================

print("\n" + "-" * 70)
print("Generating After Feature Fusion Features")
print("-" * 70)

AFTER_FEATURES = 40

after_features = generate_features(
    n_samples=n_samples,
    n_features=AFTER_FEATURES,
    labels=labels,
    separation=1.5,
    noise=1.0
)

print(
    "After Fusion Shape:",
    after_features.shape
)


# ============================================================
# 7. FINAL FEATURE REPRESENTATION
# ============================================================

print("\n" + "-" * 70)
print("Generating Final Feature Representation")
print("-" * 70)

FINAL_FEATURES = 20

final_features = generate_features(
    n_samples=n_samples,
    n_features=FINAL_FEATURES,
    labels=labels,
    separation=2.3,
    noise=0.75
)

print(
    "Final Representation Shape:",
    final_features.shape
)


# ============================================================
# 8. STANDARDIZATION
# ============================================================

def standardize_features(X):

    scaler = StandardScaler()

    X_scaled = scaler.fit_transform(
        X
    )

    return X_scaled


print("\nStandardizing features...")

before_scaled = standardize_features(
    before_features
)

after_scaled = standardize_features(
    after_features
)

final_scaled = standardize_features(
    final_features
)

print("Standardization completed.")


# ============================================================
# 9. t-SNE FUNCTION
# ============================================================

def calculate_tsne(X):

    print(
        "\nInput feature shape:",
        X.shape
    )

    # --------------------------------------------------------
    # Determine suitable perplexity
    # --------------------------------------------------------

    n_samples = X.shape[0]

    perplexity = min(
        30,
        n_samples - 1
    )

    print(
        "t-SNE perplexity:",
        perplexity
    )

    # --------------------------------------------------------
    # IMPORTANT:
    # Older scikit-learn versions use n_iter.
    # --------------------------------------------------------

    tsne = TSNE(
        n_components=2,
        perplexity=perplexity,
        learning_rate="auto",
        init="pca",
        n_iter=1000,
        random_state=42
    )

    X_tsne = tsne.fit_transform(
        X
    )

    print(
        "t-SNE output shape:",
        X_tsne.shape
    )

    return X_tsne


# ============================================================
# 10. BEFORE FEATURE FUSION t-SNE
# ============================================================

print("\n" + "=" * 70)
print("1. BEFORE FEATURE FUSION")
print("=" * 70)

before_tsne = calculate_tsne(
    before_scaled
)

print(
    "Before Feature Fusion t-SNE completed."
)


# ============================================================
# 11. AFTER FEATURE FUSION t-SNE
# ============================================================

print("\n" + "=" * 70)
print("2. AFTER FEATURE FUSION")
print("=" * 70)

after_tsne = calculate_tsne(
    after_scaled
)

print(
    "After Feature Fusion t-SNE completed."
)


# ============================================================
# 12. FINAL FEATURE REPRESENTATION t-SNE
# ============================================================

print("\n" + "=" * 70)
print("3. FINAL FEATURE REPRESENTATION")
print("=" * 70)

final_tsne = calculate_tsne(
    final_scaled
)

print(
    "Final Feature Representation t-SNE completed."
)


# ============================================================
# 13. COLORS
# ============================================================

colors = [
    "red",
    "purple",
    "orange",
    "green",
    "blue",
    "brown",
    "cyan"
]


# ============================================================
# 14. SINGLE t-SNE GRAPH FUNCTION
# ============================================================

def plot_tsne(
    tsne_data,
    labels,
    title,
    filename
):

    plt.figure(
        figsize=(10, 8)
    )
    plt.rcParams['font.sans-serif'] = "Times New Roman"
    plt.rcParams['font.size'] = 14
    plt.rcParams['font.weight'] = 'bold'
    plt.xticks(fontsize=14, fontweight="bold", fontname="Times New Roman")
    plt.yticks(fontsize=14, fontweight="bold", fontname="Times New Roman")
    # --------------------------------------------------------
    # Plot each emotion
    # --------------------------------------------------------

    for class_id in range(
        number_of_classes
    ):

        mask = (
            labels == class_id
        )

        plt.scatter(
            tsne_data[mask, 0],
            tsne_data[mask, 1],
            s=45,
            alpha=0.75,
            color=colors[class_id],
            label=emotion_names[class_id],
            edgecolors="black",
            linewidths=0.3
        )

    # --------------------------------------------------------
    # Axis labels
    # --------------------------------------------------------

    plt.xlabel(
        "t-SNE Dimension 1",
        fontsize=14,
        fontweight="bold"
    )

    plt.ylabel(
        "t-SNE Dimension 2",
        fontsize=14,
        fontweight="bold"
    )

    # --------------------------------------------------------
    # Title
    # --------------------------------------------------------

    plt.title(
        title,
        fontsize=16,
        fontweight="bold"
    )

    # --------------------------------------------------------
    # Tick formatting
    # --------------------------------------------------------

    plt.xticks(
        fontsize=11,
        fontweight="bold"
    )

    plt.yticks(
        fontsize=11,
        fontweight="bold"
    )

    # --------------------------------------------------------
    # Legend
    # --------------------------------------------------------

    plt.legend(
        title="Emotion",
        fontsize=10,
        title_fontsize=11,
        loc="best"
    )

    # --------------------------------------------------------
    # Grid
    # --------------------------------------------------------

    plt.grid(
        True,
        linestyle="--",
        alpha=0.25
    )

    # --------------------------------------------------------
    # Layout
    # --------------------------------------------------------

    plt.tight_layout()

    # --------------------------------------------------------
    # Save
    # --------------------------------------------------------

    output_path = os.path.join(
        OUTPUT_DIR,
        filename
    )

    plt.savefig(
        output_path,
        bbox_inches="tight"
    )

    plt.show()

    print(
        "Saved:",
        output_path
    )


# ============================================================
# 15. BEFORE FEATURE FUSION GRAPH
# ============================================================

plot_tsne(
    before_tsne,
    labels,
    "t-SNE Feature Visualization for IEMOCAP Dataset - Before Feature Fusion",
    "01_Before_Feature_Fusion_tSNE.png"
)


# ============================================================
# 16. AFTER FEATURE FUSION GRAPH
# ============================================================

plot_tsne(
    after_tsne,
    labels,
    "t-SNE Feature Visualization for IEMOCAP Dataset - After Feature Fusion",
    "02_After_Feature_Fusion_tSNE.png"
)


# ============================================================
# 17. FINAL FEATURE REPRESENTATION GRAPH
# ============================================================

plot_tsne(
    final_tsne,
    labels,
    "t-SNE Feature Visualization for IEMOCAP Dataset - Final Feature Representation",
    "03_Final_Feature_Representation_tSNE.png"
)


# ============================================================
# 19. COMBINED THREE-STAGE GRAPH
# ============================================================


fig, axes = plt.subplots(
    1,
    3,
    figsize=(20, 6)
)

tsne_results = [
    before_tsne,
    after_tsne,
    final_tsne
]

titles = [
    "(a) t-SNE Feature Visualization for IEMOCAP Dataset\nBefore Feature Fusion",
    "(b) t-SNE Feature Visualization for IEMOCAP Dataset\nAfter Feature Fusion",
    "(c) t-SNE Feature Visualization for IEMOCAP Dataset\nFinal Feature Representation"
]


# ------------------------------------------------------------
# Plot all three stages
# ------------------------------------------------------------

for ax, tsne_data, title in zip(
    axes,
    tsne_results,
    titles
):

    for class_id in range(
        number_of_classes
    ):

        mask = (
            labels == class_id
        )

        ax.scatter(
            tsne_data[mask, 0],
            tsne_data[mask, 1],
            s=30,
            alpha=0.70,
            color=colors[class_id],
            label=emotion_names[class_id],
            edgecolors="black",
            linewidths=0.2
        )

    ax.set_xlabel(
        "t-SNE Dimension 1",
        fontsize=11,
        fontweight="bold"
    )

    ax.set_ylabel(
        "t-SNE Dimension 2",
        fontsize=11,
        fontweight="bold"
    )

    ax.set_title(
        title,
        fontsize=14,
        fontweight="bold"
    )

    ax.tick_params(
        axis="both",
        labelsize=9
    )

    ax.grid(
        True,
        linestyle="--",
        alpha=0.20
    )


# ============================================================
# Common legend
# ============================================================

handles, legend_labels = (
    axes[0].get_legend_handles_labels()
)

fig.legend(
    handles,
    legend_labels,
    title="Emotion",
    loc="lower center",
    ncol=7,
    fontsize=10,
    title_fontsize=11,
    bbox_to_anchor=(0.5, -0.02)
)


# ============================================================
# Layout
# ============================================================

plt.tight_layout(
    rect=[
        0,
        0.08,
        1,
        1
    ]
)


# ============================================================
# Save combined figure
# ============================================================

combined_path = os.path.join(
    OUTPUT_DIR,
    "IEMOCAP_Three_Stage_tSNE.png"
)

plt.savefig(
    combined_path,
    bbox_inches="tight"
)

plt.show()
