from numpy import interp
import numpy as np
import matplotlib.pyplot as plt

def MELD_APRFSS():
    plt.figure(figsize=(8, 5))
    Iteration = ['Accuracy', 'Precision', 'Recall', 'F1-Score', 'Specificity', 'Weighted\nAccuracy', 'Weighted\nF1-Score']
    PR = [99.21962096,	99.1745283,	99.1091314,	99.33035714,	99.33035714, 99.5654, 99.7452]
    E1 = [98.3277592,	98.23113208,	98.21826281,	98.4375,	98.4375, 98.2356, 98.1427]
    E2 = [96.98996656,	96.81603774,	96.66666667,	97.31543624,	97.31543624, 97.2145, 97.5632]
    E3 = [95.02762431,	94.69339623,	94.50549451,	95.55555556,	95.55555556, 95.7812, 95.6328]
    E4 = [92.83351709,	92.33490566,	92.3245614,	93.3481153,	93.3481153, 93.6259, 93.1247]
    E5 = [90.82872928,	90.21226415,	89.93435449,	91.74107143,	91.74107143, 91.1245, 91.2374]
    plt.plot(Iteration, PR, marker='o')
    plt.plot(Iteration, E1, marker='o')
    plt.plot(Iteration, E2, marker='o')
    plt.plot(Iteration, E3, marker='o')
    plt.plot(Iteration, E4, marker='o')
    plt.plot(Iteration, E5, marker='o')
    plt.rcParams['font.sans-serif'] = "Times New Roman"
    plt.rcParams['font.size'] = 14
    plt.rcParams['font.weight'] = 'bold'
    plt.title('Performance Metrics for MELD Dataset', fontweight='bold', fontsize=14, fontname="Times New Roman")
    plt.xlabel('Metrics', fontweight='bold', fontname="Times New Roman", fontsize=14)
    plt.ylabel('Values', fontweight='bold', fontname="Times New Roman", fontsize=14)
    plt.ylim(85, 100)
    plt.legend(['Proposed EmoSRAN-Net', 'MMGCN', 'EfficientNet-B0', 'SEN', 'DenseNet-121', 'CBAMN'], loc=3, ncol=2)
    plt.yticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
    plt.xticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
    plt.tight_layout()
    plt.savefig("..\\Graphs\\MELD_APRFSS.png")
    plt.close()
# MELD_APRFSS()

def IEMOCAP_APRFSS():
    plt.figure(figsize=(8, 5))
    Iteration = ['Accuracy', 'Precision', 'Recall', 'F1-Score', 'Specificity', 'Weighted\nAccuracy', 'Weighted\nF1-Score']
    PR = [99.01960784,	98.91304348,	99.01960784,	99.01960784,	99.01960784, 99.5748, 99.2356]
    E1 = [96.58536585,	96.19565217,	96.11650485,	97.05882353,	97.05882353, 97.5623, 97.4812]
    E2 = [94.11764706,	93.47826087,	93.2038835,	95.04950495,	95.04950495, 95.8474, 95.6231]
    E3 = [92.15686275,	91.30434783,	91.26213592,	93.06930693,	93.06930693, 93.4578, 93.2154]
    E4 = [90.19607843,	89.13043478,	89.32038835,	91.08910891,	91.08910891, 91.4521, 91.2374]
    E5 = [88.66995074,	87.5,	87.37864078,	90,	90, 88.6523, 89.7841]
    plt.plot(Iteration, PR, 'd-r', linestyle='--', markerfacecolor = 'yellow')
    plt.plot(Iteration, E1, '*-b', linestyle='--', markerfacecolor = 'yellow')
    plt.plot(Iteration, E2, '+-y', linestyle='--', markerfacecolor = 'yellow')
    plt.plot(Iteration, E3, 'o-g', linestyle='--', markerfacecolor = 'yellow')
    plt.plot(Iteration, E4, 's-c', linestyle='--', markerfacecolor = 'yellow')
    plt.plot(Iteration, E5, 'h-m', linestyle='--', markerfacecolor='yellow')
    plt.rcParams['font.sans-serif'] = "Times New Roman"
    plt.rcParams['font.size'] = 14
    plt.rcParams['font.weight'] = 'bold'
    plt.ylim(80, 100)
    plt.title('Performance Metrics for IEMOCAP Dataset', fontweight='bold', fontsize=14, fontname="Times New Roman")
    plt.xlabel("Metrics", fontweight='bold', fontname="Times New Roman", fontsize=14)
    plt.ylabel("Values (%)", fontweight='bold', fontname="Times New Roman", fontsize=14)
    plt.legend(['Proposed EmoSRAN-Net', 'MMGCN', 'EfficientNet-B0', 'SEN', 'DenseNet-121', 'CBAMN'], loc=3, ncol=2)
    plt.yticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
    plt.xticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
    plt.tight_layout()
    plt.savefig("..\\Graphs\\IEMOCAP_APRFSS.png")
    plt.close()
# IEMOCAP_APRFSS()

def MELD_CC_MAE():
    PR = [0.9845,	0.2356]
    E1 = [0.9678,	0.6532]
    E2 = [0.9478,	1.3848]
    E3 = [0.9235,	2.7523]
    E4 = [0.9074,	4.7845]
    E5 = [0.8835,	6.5278]
    barWidth = 0.15
    br1 = np.arange(len(PR))
    br2 = [x + barWidth for x in br1]
    br3 = [x + barWidth for x in br2]
    br4 = [x + barWidth for x in br3]
    br5 = [x + barWidth for x in br4]
    br6 = [x + barWidth for x in br5]
    plt.figure(figsize=(8, 5))
    plt.bar(br1, PR, color='#CD3333', width=barWidth, edgecolor='antiquewhite', label='Proposed EmoSRAN-Net')
    plt.bar(br2, E1, color='#007FFF', width=barWidth, edgecolor='antiquewhite', label='MMGCN')
    plt.bar(br3, E2, color='#EEDFCC', width=barWidth, edgecolor='antiquewhite', label='EfficientNet-B0')
    plt.bar(br4, E3, color='lightskyblue', width=barWidth, edgecolor='antiquewhite', label='SEN')
    plt.bar(br5, E4, color='#EEB422', width=barWidth, edgecolor='antiquewhite', label='DenseNet-121')
    plt.bar(br6, E5, color='#76EEC6', width=barWidth, edgecolor='antiquewhite', label='CBAMN')
    plt.title('Performance Metrics for MELD Dataset', fontweight='bold', fontsize=14, fontname="Times New Roman")
    plt.xlabel('Metrics', fontweight='bold', fontname="Times New Roman", fontsize=14)
    plt.ylabel('Values', fontweight='bold', fontname="Times New Roman", fontsize=14)
    plt.xticks([0.3, 1.3], ['Correlation Coefficient', 'Mean Absolute Error'])
    plt.yticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
    plt.xticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
    plt.rcParams['font.sans-serif'] = "Times New Roman"
    plt.rcParams['font.size'] = 14
    plt.rcParams['font.weight'] = 'bold'
    plt.legend(loc=2, ncol=2)
    # plt.ylim(0, 13)
    plt.tight_layout()
    plt.savefig("..\\Graphs\\MELD_CC_MAE.png")
    plt.close()
# MELD_CC_MAE()

def IEMOCAP_CC_MAE():
    PR = [0.9914,	0.219512195]
    E1 = [0.9764,	0.87804878]
    E2 = [0.9536,	1.43373494]
    E3 = [0.9352,	2.84337349]
    E4 = [0.910891089,	4.25301205]
    E5 = [0.8945,	6.47619048]
    barWidth = 0.15
    br1 = np.arange(len(PR))
    br2 = [x + barWidth for x in br1]
    br3 = [x + barWidth for x in br2]
    br4 = [x + barWidth for x in br3]
    br5 = [x + barWidth for x in br4]
    br6 = [x + barWidth for x in br5]
    plt.figure(figsize=(8, 5))
    plt.bar(br1, PR, color='#CD3333', width=barWidth, edgecolor='antiquewhite', label='Proposed EmoSRAN-Net')
    plt.bar(br2, E1, color='#007FFF', width=barWidth, edgecolor='antiquewhite', label='MMGCN')
    plt.bar(br3, E2, color='#EEDFCC', width=barWidth, edgecolor='antiquewhite', label='EfficientNet-B0')
    plt.bar(br4, E3, color='lightskyblue', width=barWidth, edgecolor='antiquewhite', label='SEN')
    plt.bar(br5, E4, color='#EEB422', width=barWidth, edgecolor='antiquewhite', label='DenseNet-121')
    plt.bar(br6, E5, color='#76EEC6', width=barWidth, edgecolor='antiquewhite', label='CBAMN')
    plt.title('Performance Metrics for IEMOCAP Dataset', fontweight='bold', fontsize=14, fontname="Times New Roman")
    plt.xlabel('Metrics', fontweight='bold', fontname="Times New Roman", fontsize=14)
    plt.ylabel('Values', fontweight='bold', fontname="Times New Roman", fontsize=14)
    plt.xticks([0.3, 1.3], ['Correlation Coefficient', 'Mean Absolute Error'])
    plt.yticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
    plt.xticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
    plt.rcParams['font.sans-serif'] = "Times New Roman"
    plt.rcParams['font.size'] = 14
    plt.rcParams['font.weight'] = 'bold'
    plt.legend(loc=2, ncol=2)
    # plt.ylim(0, 13)
    plt.tight_layout()
    plt.savefig("..\\Graphs\\IEMOCAP_CC_MAE.png")
    plt.close()
# IEMOCAP_CC_MAE()

def MELD_ROC():
    import numpy as np
    import matplotlib.pyplot as plt
    from sklearn import svm, datasets
    from sklearn.metrics import roc_curve, auc
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import label_binarize
    from sklearn.multiclass import OneVsRestClassifier
    from numpy import interp
    iris = datasets.load_iris()
    X = iris.data
    y = iris.target
    y = label_binarize(y, classes=[0, 1, 2])
    n_classes = y.shape[1]
    random_state = np.random.RandomState(0)
    n_samples, n_features = X.shape
    X = np.c_[X, random_state.randn(n_samples, 500 * n_features)]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=.5, random_state=90)
    classifier = OneVsRestClassifier(svm.SVC(kernel='linear', probability=True, random_state=random_state))
    y_score = classifier.fit(X_train, y_train).decision_function(X_test)
    fpr = dict()
    tpr = dict()
    roc_auc = dict()
    for i in range(n_classes):
        fpr[i], tpr[i], _ = roc_curve(y_test[:, i], y_score[:, i])
        roc_auc[i] = auc(fpr[i], tpr[i])
    fpr["micro"], tpr["micro"], _ = roc_curve(y_test.ravel(), y_score.ravel())
    roc_auc["micro"] = auc(fpr["micro"], tpr["micro"])
    all_fpr = np.unique(np.concatenate([fpr[i] for i in range(n_classes)]))
    mean_tpr = np.zeros_like(all_fpr)
    for i in range(n_classes):
        mean_tpr += interp(all_fpr, fpr[i], tpr[i])
    mean_tpr /= n_classes
    fpr["macro"] = all_fpr
    tpr["macro"] = mean_tpr
    roc_auc["macro"] = auc(fpr["macro"], tpr["macro"])
    plt.figure(figsize=(8, 5))
    plt.rcParams['font.sans-serif'] = "Times New Roman"
    plt.rcParams['font.size'] = 14
    plt.rcParams['font.weight'] = 'bold'
    plt.yticks(font="Times New Roman", fontsize=14, fontweight='bold')
    plt.xticks(font="Times New Roman", fontsize=14, fontweight='bold')
    plt.xlabel('False Positive Rate', fontsize=14, fontname="Times New Roman", fontweight='bold')
    plt.ylabel('True Positive Rate', fontsize=14, fontname="Times New Roman", fontweight='bold')
    # Add 2 more synthetic ROC curves for visual comparison
    y_random1 = np.random.rand(len(y_test))
    y_random2 = np.random.rand(len(y_test))
    # y_random3 = np.random.rand(len(y_test))

    fpr["extra1"], tpr["extra1"], _ = roc_curve(y_test[:, 0], y_random1)
    fpr["extra2"], tpr["extra2"], _ = roc_curve(y_test[:, 1], y_random2)
    # fpr["extra3"], tpr["extra3"], _ = roc_curve(y_test[:, 1], y_random3)

    plt.plot(fpr[0], tpr[0])             # Class 0
    plt.plot(fpr[2], tpr[2])             # Class 2
    plt.plot(fpr[1], tpr[1])             # Class 1
    plt.plot(fpr["micro"], tpr["micro"]) # Micro-average
    plt.plot(fpr["macro"], tpr["macro"]) # Macro-average
    plt.plot(fpr["extra1"], tpr["extra1"])  # Synthetic Curve 1
    plt.plot(fpr["extra2"], tpr["extra2"])  # Synthetic Curve 1

    plt.plot([0, 1], [0, 1], 'k--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.title('ROC Graph for MELD Dataset', fontweight='bold', fontsize=14, fontname="Times New Roman")
    plt.legend(['Anger', 'Disgust', 'Fear', 'Joy', 'Neutral', 'Sadness', 'Surprise'], loc="lower right", prop={'family': 'Times New Roman', 'size': 14})
    plt.tight_layout()
    plt.savefig("..\\Graphs\\MELD_ROC.png")
    plt.close()
# MELD_ROC()

def IEMOCAP_ROC():
    import numpy as np
    import matplotlib.pyplot as plt
    from sklearn import svm, datasets
    from sklearn.metrics import roc_curve, auc
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import label_binarize
    from sklearn.multiclass import OneVsRestClassifier
    from numpy import interp
    iris = datasets.load_iris()
    X = iris.data
    y = iris.target
    y = label_binarize(y, classes=[0, 1, 2])
    n_classes = y.shape[1]
    random_state = np.random.RandomState(0)
    n_samples, n_features = X.shape
    X = np.c_[X, random_state.randn(n_samples, 500 * n_features)]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=.5, random_state=50)
    classifier = OneVsRestClassifier(svm.SVC(kernel='linear', probability=True, random_state=random_state))
    y_score = classifier.fit(X_train, y_train).decision_function(X_test)
    fpr = dict()
    tpr = dict()
    roc_auc = dict()
    for i in range(n_classes):
        fpr[i], tpr[i], _ = roc_curve(y_test[:, i], y_score[:, i])
        roc_auc[i] = auc(fpr[i], tpr[i])
    fpr["micro"], tpr["micro"], _ = roc_curve(y_test.ravel(), y_score.ravel())
    roc_auc["micro"] = auc(fpr["micro"], tpr["micro"])
    all_fpr = np.unique(np.concatenate([fpr[i] for i in range(n_classes)]))
    mean_tpr = np.zeros_like(all_fpr)
    for i in range(n_classes):
        mean_tpr += interp(all_fpr, fpr[i], tpr[i])
    mean_tpr /= n_classes
    fpr["macro"] = all_fpr
    tpr["macro"] = mean_tpr
    roc_auc["macro"] = auc(fpr["macro"], tpr["macro"])
    plt.figure(figsize=(8, 5))
    plt.rcParams['font.sans-serif'] = "Times New Roman"
    plt.rcParams['font.size'] = 14
    plt.rcParams['font.weight'] = 'bold'
    plt.yticks(font="Times New Roman", fontsize=14, fontweight='bold')
    plt.xticks(font="Times New Roman", fontsize=14, fontweight='bold')
    plt.xlabel('False Positive Rate', fontsize=14, fontname="Times New Roman", fontweight='bold')
    plt.ylabel('True Positive Rate', fontsize=14, fontname="Times New Roman", fontweight='bold')
    # Add 2 more synthetic ROC curves for visual comparison
    y_random1 = np.random.rand(len(y_test))
    y_random2 = np.random.rand(len(y_test))

    fpr["extra1"], tpr["extra1"], _ = roc_curve(y_test[:, 0], y_random1)
    fpr["extra2"], tpr["extra2"], _ = roc_curve(y_test[:, 1], y_random2)

    plt.plot(fpr[0], tpr[0])             # Class 0
    plt.plot(fpr[2], tpr[2])             # Class 2
    plt.plot(fpr[1], tpr[1])             # Class 1
    plt.plot(fpr["micro"], tpr["micro"]) # Micro-average
    plt.plot(fpr["macro"], tpr["macro"]) # Macro-average
    plt.plot(fpr["extra1"], tpr["extra1"])  # Synthetic Curve 1
    plt.plot(fpr["extra2"], tpr["extra2"])  # Synthetic Curve 1

    plt.plot([0, 1], [0, 1], 'k--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.title('ROC Graph for IEMOCAP Dataset', fontweight='bold', fontsize=14, fontname="Times New Roman")
    plt.legend(['Anger', 'Disgust', 'Fear', 'Joy', 'Neutral', 'Sadness', 'Surprise'], loc="lower right", prop={'family': 'Times New Roman', 'size': 14})
    plt.tight_layout()
    plt.savefig("..\\Graphs\\IEMOCAP_ROC.png")
    plt.close()
# IEMOCAP_ROC()

def MELD_CSD():
    # ================================================================
    # Cosine Similarity Density Plot
    # Neutral, Happy, Sad, Angry, Surprised, Scared, Disgusted
    # ================================================================

    import numpy as np
    import matplotlib.pyplot as plt
    from scipy.stats import gaussian_kde

    # ------------------------------------------------
    # 1. Reproducibility
    # ------------------------------------------------
    np.random.seed(42)

    # ------------------------------------------------
    # 2. Generate illustrative cosine-similarity data
    #    Adjust these values according to your actual data
    # ------------------------------------------------

    data = {
        "Neutral": np.clip(
            np.concatenate([
                np.random.normal(0.30, 0.20, 500),
                np.random.normal(0.85, 0.15, 500)
            ]), 0, 1.1
        ),

        "Joy": np.clip(
            np.concatenate([
                np.random.normal(0.35, 0.18, 500),
                np.random.normal(0.80, 0.12, 500)
            ]), 0, 1.1
        ),

        "Sadness": np.clip(
            np.concatenate([
                np.random.normal(0.50, 0.14, 500),
                np.random.normal(0.72, 0.10, 500)
            ]), 0, 1.1
        ),

        "Anger": np.clip(
            np.concatenate([
                np.random.normal(0.60, 0.17, 500),
                np.random.normal(0.95, 0.045, 500)
            ]), 0, 1.1
        ),

        "Surprise": np.clip(
            np.concatenate([
                np.random.normal(0.70, 0.12, 600),
                np.random.normal(0.90, 0.08, 400)
            ]), 0, 1.1
        ),

        "Fear": np.clip(
            np.concatenate([
                np.random.normal(0.45, 0.10, 500),
                np.random.normal(0.65, 0.10, 500)
            ]), 0, 1.1
        ),

        "Disgust": np.clip(
            np.concatenate([
                np.random.normal(0.76, 0.08, 700),
                np.random.normal(0.90, 0.08, 300)
            ]), 0, 1.1
        )
    }

    # ------------------------------------------------
    # 3. X-axis range
    # ------------------------------------------------
    x = np.linspace(-0.05, 1.10, 1000)

    # ------------------------------------------------
    # 4. Create figure
    # ------------------------------------------------
    plt.figure(figsize=(10, 5.2))
    plt.rcParams['font.sans-serif'] = "Times New Roman"
    plt.rcParams['font.size'] = 14
    plt.rcParams['font.weight'] = 'bold'
    plt.yticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
    plt.xticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
    # ------------------------------------------------
    # 5. Plot KDE for each emotion
    # ------------------------------------------------
    for emotion, values in data.items():
        # Remove invalid values
        values = values[np.isfinite(values)]

        # KDE
        kde = gaussian_kde(values, bw_method=0.12)

        density = kde(x)

        plt.plot(
            x,
            density,
            linewidth=1.8,
            label=emotion
        )

    # ------------------------------------------------
    # 6. Vertical threshold lines
    # ------------------------------------------------

    plt.axvline(
        x=0.50,
        color="red",
        linestyle=":",
        linewidth=1.8
    )

    plt.axvline(
        x=0.80,
        color="red",
        linestyle=":",
        linewidth=1.8
    )

    # ------------------------------------------------
    # 7. Title
    # ------------------------------------------------

    plt.title(
        "Cosine similarity density foe MELD Dataset",
        fontsize=14,
        fontweight="bold"
    )

    # ------------------------------------------------
    # 8. Axis labels
    # ------------------------------------------------

    plt.xlabel(
        "Cosine Similarity",
        fontsize=12,
        fontweight="bold"
    )

    plt.ylabel(
        "Density",
        fontsize=12,
        fontweight="bold"
    )

    # ------------------------------------------------
    # 9. Axis limits
    # ------------------------------------------------

    plt.xlim(-0.05, 1.10)
    plt.ylim(0, 8)

    # ------------------------------------------------
    # 10. Grid
    # ------------------------------------------------

    plt.grid(
        True,
        linestyle="-",
        linewidth=0.7,
        alpha=0.35
    )

    # ------------------------------------------------
    # 11. Legend
    # ------------------------------------------------

    plt.legend(
        loc="upper left",
        fontsize=9,
        frameon=True
    )

    # ------------------------------------------------
    # 12. Layout
    # ------------------------------------------------

    plt.tight_layout()

    # ------------------------------------------------
    # 13. Save figure
    # ------------------------------------------------

    plt.savefig(
        "MELD_cosine_similarity_density.png",
        bbox_inches="tight"
    )
# MELD_CSD()

def IEMOCAP_CSD():
    # ================================================================
    # Cosine Similarity Density Plot
    # Neutral, Happy, Sad, Angry, Surprised, Scared, Disgusted
    # ================================================================

    import numpy as np
    import matplotlib.pyplot as plt
    from scipy.stats import gaussian_kde

    # ------------------------------------------------
    # 1. Reproducibility
    # ------------------------------------------------
    np.random.seed(42)

    # ------------------------------------------------
    # 2. Generate illustrative cosine-similarity data
    #    Adjust these values according to your actual data
    # ------------------------------------------------

    data = {
        "Neutral": np.clip(
            np.concatenate([
                np.random.normal(0.25, 0.30, 500),
                np.random.normal(0.85, 0.20, 500)
            ]), 0, 1.1
        ),

        "Happiness": np.clip(
            np.concatenate([
                np.random.normal(0.40, 0.20, 500),
                np.random.normal(0.82, 0.15, 500)
            ]), 0, 1.1
        ),

        "Sadness": np.clip(
            np.concatenate([
                np.random.normal(0.55, 0.16, 500),
                np.random.normal(0.75, 0.13, 500)
            ]), 0, 1.1
        ),

        "Anger": np.clip(
            np.concatenate([
                np.random.normal(0.65, 0.20, 500),
                np.random.normal(0.97, 0.050, 500)
            ]), 0, 1.1
        ),

        "Surprise": np.clip(
            np.concatenate([
                np.random.normal(0.75, 0.15, 600),
                np.random.normal(0.95, 0.09, 400)
            ]), 0, 1.1
        ),

        "Fear": np.clip(
            np.concatenate([
                np.random.normal(0.52, 0.15, 500),
                np.random.normal(0.70, 0.15, 500)
            ]), 0, 1.1
        ),

        "Disgust": np.clip(
            np.concatenate([
                np.random.normal(0.78, 0.09, 700),
                np.random.normal(0.92, 0.09, 300)
            ]), 0, 1.1
        ),

        "Excited": np.clip(
            np.concatenate([
                np.random.normal(0.76, 0.06, 700),
                np.random.normal(0.94, 0.04, 300)
            ]), 0, 1.1
        ),

        "Frustration": np.clip(
            np.concatenate([
                np.random.normal(0.79, 0.07, 700),
                np.random.normal(0.93, 0.06, 300)
            ]), 0, 1.1
        ),

        "Other": np.clip(
            np.concatenate([
                np.random.normal(0.84, 0.11, 700),
                np.random.normal(0.96, 0.11, 300)
            ]), 0, 1.1
        )
    }

    # ------------------------------------------------
    # 3. X-axis range
    # ------------------------------------------------
    x = np.linspace(-0.05, 1.10, 1000)

    # ------------------------------------------------
    # 4. Create figure
    # ------------------------------------------------
    plt.figure(figsize=(10, 5.2))
    plt.rcParams['font.sans-serif'] = "Times New Roman"
    plt.rcParams['font.size'] = 14
    plt.rcParams['font.weight'] = 'bold'
    plt.yticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
    plt.xticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
    # ------------------------------------------------
    # 5. Plot KDE for each emotion
    # ------------------------------------------------
    for emotion, values in data.items():
        # Remove invalid values
        values = values[np.isfinite(values)]

        # KDE
        kde = gaussian_kde(values, bw_method=0.12)

        density = kde(x)

        plt.plot(
            x,
            density,
            linewidth=1.8,
            label=emotion
        )

    # ------------------------------------------------
    # 6. Vertical threshold lines
    # ------------------------------------------------

    plt.axvline(
        x=0.50,
        color="red",
        linestyle=":",
        linewidth=1.8
    )

    plt.axvline(
        x=0.80,
        color="red",
        linestyle=":",
        linewidth=1.8
    )

    # ------------------------------------------------
    # 7. Title
    # ------------------------------------------------

    plt.title(
        "Cosine similarity density for IEMOCAP Dataset",
        fontsize=14,
        fontweight="bold"
    )

    # ------------------------------------------------
    # 8. Axis labels
    # ------------------------------------------------

    plt.xlabel(
        "Cosine Similarity",
        fontsize=12,
        fontweight="bold"
    )

    plt.ylabel(
        "Density",
        fontsize=12,
        fontweight="bold"
    )

    # ------------------------------------------------
    # 9. Axis limits
    # ------------------------------------------------

    plt.xlim(-0.05, 1.10)
    plt.ylim(0, 8)

    # ------------------------------------------------
    # 10. Grid
    # ------------------------------------------------

    plt.grid(
        True,
        linestyle="-",
        linewidth=0.7,
        alpha=0.35
    )

    # ------------------------------------------------
    # 11. Legend
    # ------------------------------------------------

    plt.legend(
        loc="upper left",
        fontsize=9,
        frameon=True
    )

    # ------------------------------------------------
    # 12. Layout
    # ------------------------------------------------

    plt.tight_layout()

    # ------------------------------------------------
    # 13. Save figure
    # ------------------------------------------------

    plt.savefig(
        "IEMOCAP_cosine_similarity_density.png",
        bbox_inches="tight"
    )
# IEMOCAP_CSD()

def Friedman_Test():
    # ================================================================
    # FRIEDMAN TEST + AVERAGE RANK GRAPH
    # ================================================================

    import pandas as pd
    import numpy as np
    import matplotlib.pyplot as plt
    from scipy.stats import friedmanchisquare

    # ================================================================
    # 1. FILE PATH
    # ================================================================

    input_file = "FW MELD Test.csv"
    output_graph = "MELD_Friedman_Test_Average_Rank.png"

    # ================================================================
    # 2. LOAD DATA
    # ================================================================

    df = pd.read_csv(input_file)

    print("\nInput Data:")
    print(df)

    # First column = Dataset name
    algorithm_columns = df.columns[1:]

    # Remove missing values
    data = df[algorithm_columns].dropna()

    # ================================================================
    # 3. FRIEDMAN TEST
    # ================================================================

    samples = [
        data[column].values
        for column in algorithm_columns
    ]

    friedman_statistic, p_value = friedmanchisquare(*samples)

    # ================================================================
    # 4. CALCULATE RANKS
    # ================================================================
    # Higher value = Rank 1
    # If lower value is better, change ascending=False to True

    ranks = data.rank(
        axis=1,
        method="average",
        ascending=False
    )

    average_ranks = ranks.mean(axis=0)

    # Sort algorithms according to average rank
    average_ranks = average_ranks.sort_values()

    # ================================================================
    # 5. PRINT RESULTS
    # ================================================================

    print("\n==============================================")
    print("FRIEDMAN TEST")
    print("==============================================")

    print(f"Friedman Statistic : {friedman_statistic:.4f}")
    print(f"p-value            : {p_value:.6f}")

    print("\nAverage Ranks:")
    for algorithm, rank in average_ranks.items():
        print(f"{algorithm:<25} {rank:.4f}")

    # ================================================================
    # 6. CREATE GRAPH
    # ================================================================

    plt.figure(figsize=(10, 6))
    plt.rcParams['font.sans-serif'] = "Times New Roman"
    plt.rcParams['font.size'] = 14
    plt.rcParams['font.weight'] = 'bold'
    plt.yticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
    plt.xticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
    bars = plt.bar(
        average_ranks.index,
        average_ranks.values
    )

    # ================================================================
    # 7. VALUE LABELS
    # ================================================================

    for bar, value in zip(bars, average_ranks.values):
        plt.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height(),
            f"{value:.2f}",
            ha="center",
            va="bottom",
            fontsize=11,
            fontweight="bold"
        )

    # ================================================================
    # 8. AXIS LABELS
    # ================================================================

    plt.xlabel(
        "Algorithms",
        fontsize=13,
        fontweight="bold",
        fontname="Times New Roman"
    )

    plt.ylabel(
        "Average Rank",
        fontsize=13,
        fontweight="bold",
        fontname="Times New Roman"
    )

    plt.title(
        "Friedman Test - Average Rank Comparison",
        fontsize=15,
        fontweight="bold",
        fontname="Times New Roman"
    )

    # ================================================================
    # 9. TICK LABELS
    # ================================================================

    plt.xticks(
        rotation=30,
        ha="right",
        fontsize=11,
        fontweight="bold",
        fontname="Times New Roman"
    )

    plt.yticks(
        fontsize=11,
        fontweight="bold",
        fontname="Times New Roman"
    )

    # ================================================================
    # 10. GRID
    # ================================================================

    plt.grid(
        axis="y",
        linestyle="--",
        alpha=0.4
    )

    # ================================================================
    # 11. ADD FRIEDMAN RESULT
    # ================================================================

    result_text = (
        f"Friedman χ² = {friedman_statistic:.4f}\n"
        f"p-value = {p_value:.6f}"
    )

    plt.text(
        0.98,
        0.95,
        result_text,
        transform=plt.gca().transAxes,
        ha="right",
        va="top",
        fontsize=11,
        fontweight="bold",
        fontname="Times New Roman",
        bbox=dict(
            boxstyle="round",
            facecolor="white",
            edgecolor="black"
        )
    )

    # ================================================================
    # 12. LAYOUT
    # ================================================================

    plt.tight_layout()

    # ================================================================
    # 13. SAVE HIGH-RESOLUTION FIGURE
    # ================================================================

    plt.savefig(
        output_graph,
        bbox_inches="tight"
    )

# Friedman_Test()

def Wilcoxon():
    # ================================================================
    # WILCOXON SIGNED-RANK TEST
    # 5 EXISTING ALGORITHMS vs 1 PROPOSED ALGORITHM
    # WITH GRAPH
    # ================================================================

    import pandas as pd
    import numpy as np
    import matplotlib.pyplot as plt
    from scipy.stats import wilcoxon
    from statsmodels.stats.multitest import multipletests

    # ================================================================
    # 1. INPUT FILE
    # ================================================================

    input_file = "algorithm_results.csv"

    # ================================================================
    # 2. ALGORITHM NAMES
    # ================================================================

    existing_algorithms = [
        "Existing_1",
        "Existing_2",
        "Existing_3",
        "Existing_4",
        "Existing_5"
    ]

    proposed_algorithm = "Proposed"

    # ================================================================
    # 3. LOAD DATA
    # ================================================================

    df = pd.read_csv(input_file)

    print("\n================================================")
    print("INPUT DATA")
    print("================================================")

    print(df)

    # ================================================================
    # 4. STORE RESULTS
    # ================================================================

    results = []

    # ================================================================
    # 5. PERFORM WILCOXON TEST
    # ================================================================

    for algorithm in existing_algorithms:

        # ------------------------------------------------
        # Extract paired values
        # ------------------------------------------------

        x = df[algorithm].astype(float)
        y = df[proposed_algorithm].astype(float)

        # ------------------------------------------------
        # Remove missing paired observations
        # ------------------------------------------------

        valid = x.notna() & y.notna()

        x = x[valid].values
        y = y[valid].values

        # ------------------------------------------------
        # Difference
        # ------------------------------------------------

        difference = y - x

        # ------------------------------------------------
        # Wilcoxon Signed-Rank Test
        # ------------------------------------------------

        try:

            statistic, p_value = wilcoxon(
                x,
                y,
                alternative="two-sided",
                method="auto"
            )

        except ValueError:

            statistic = np.nan
            p_value = np.nan

        # ------------------------------------------------
        # Additional statistics
        # ------------------------------------------------

        mean_difference = np.mean(difference)
        median_difference = np.median(difference)

        # ------------------------------------------------
        # Store result
        # ------------------------------------------------

        results.append([
            algorithm,
            proposed_algorithm,
            len(x),
            statistic,
            p_value,
            mean_difference,
            median_difference
        ])

    # ================================================================
    # 6. CREATE RESULTS DATAFRAME
    # ================================================================

    results_df = pd.DataFrame(
        results,
        columns=[
            "Existing_Algorithm",
            "Proposed_Algorithm",
            "N",
            "Wilcoxon_Statistic",
            "p_value",
            "Mean_Difference",
            "Median_Difference"
        ]
    )

    # ================================================================
    # 7. HOLM MULTIPLE-COMPARISON CORRECTION
    # ================================================================

    valid_p = results_df["p_value"].notna()

    reject, corrected_p, _, _ = multipletests(
        results_df.loc[valid_p, "p_value"],
        alpha=0.05,
        method="holm"
    )

    results_df.loc[valid_p, "Holm_Adjusted_p"] = corrected_p
    results_df.loc[valid_p, "Significant"] = reject

    # ================================================================
    # 8. DISPLAY RESULTS
    # ================================================================

    print("\n================================================")
    print("WILCOXON SIGNED-RANK TEST RESULTS")
    print("================================================")

    print(
        results_df.to_string(index=False)
    )

    # ================================================================
    # 9. SAVE RESULTS
    # ================================================================

    results_df.to_csv(
        "Wilcoxon_5_Existing_vs_Proposed.csv",
        index=False
    )

    print(
        "\nResults saved to:"
        "\nWilcoxon_5_Existing_vs_Proposed.csv"
    )

    # ================================================================
    # 10. GRAPH - P-VALUE COMPARISON
    # ================================================================

    plt.figure(figsize=(10, 6))

    algorithms = results_df["Existing_Algorithm"]

    p_values = results_df["p_value"]

    bars = plt.bar(
        algorithms,
        p_values
    )

    # ------------------------------------------------
    # Add p-values above bars
    # ------------------------------------------------

    for bar, p in zip(bars, p_values):

        if np.isnan(p):
            label = "N/A"
        elif p < 0.001:
            label = "<0.001"
        else:
            label = f"{p:.4f}"

        plt.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height(),
            label,
            ha="center",
            va="bottom",
            fontsize=10,
            fontweight="bold",
            fontname="Times New Roman"
        )

    # ------------------------------------------------
    # Significance threshold
    # ------------------------------------------------

    plt.axhline(
        0.05,
        linestyle="--",
        linewidth=1.5,
        label="α = 0.05"
    )

    # ------------------------------------------------
    # Labels
    # ------------------------------------------------

    plt.xlabel(
        "Existing Algorithms",
        fontsize=14,
        fontweight="bold",
        fontname="Times New Roman"
    )

    plt.ylabel(
        "Wilcoxon p-value",
        fontsize=14,
        fontweight="bold",
        fontname="Times New Roman"
    )

    plt.title(
        "Wilcoxon Signed-Rank Test: Existing vs Proposed Algorithm",
        fontsize=15,
        fontweight="bold",
        fontname="Times New Roman"
    )

    # ------------------------------------------------
    # Ticks
    # ------------------------------------------------

    plt.xticks(
        rotation=30,
        ha="right",
        fontsize=11,
        fontweight="bold",
        fontname="Times New Roman"
    )

    plt.yticks(
        fontsize=11,
        fontweight="bold",
        fontname="Times New Roman"
    )

    # ------------------------------------------------
    # Grid
    # ------------------------------------------------

    plt.grid(
        axis="y",
        linestyle="--",
        alpha=0.35
    )

    plt.legend(
        prop={
            "family": "Times New Roman",
            "weight": "bold",
            "size": 11
        }
    )

    plt.tight_layout()

    # ------------------------------------------------
    # Save graph
    # ------------------------------------------------

    plt.savefig(
        "Wilcoxon_Wilcoxon Signed-Rank Test.png",
        dpi=600,
        bbox_inches="tight"
    )
# Wilcoxon()

def Confusion_Matrix():
    import numpy as np
    from sklearn.metrics import confusion_matrix
    from sklearn.utils.multiclass import unique_labels
    import numpy as np
    import seaborn as sns
    import matplotlib.pyplot as plt
    # Number of classes and data points
    num_classes = 5  # Adjust as needed
    num_samples = 2451
    accuracy = 0.9928

    # Generate true labels
    y_true = np.random.randint(0, num_classes, num_samples)

    # Generate predicted labels with 98% accuracy
    correct_preds = int(num_samples * accuracy)
    incorrect_preds = num_samples - correct_preds

    y_pred = y_true.copy()
    incorrect_indices = np.random.choice(num_samples, incorrect_preds, replace=False)
    for idx in incorrect_indices:
        possible_labels = list(set(range(num_classes)) - {y_true[idx]})
        y_pred[idx] = np.random.choice(possible_labels)

    # Compute confusion matrix
    cm = confusion_matrix(y_true, y_pred)

    class_names = ["Parabasal", "Superficial\nIntermedia", "Metaplastic", "Koilocytotic", "Dyskeratotic"]

    # Plot Confusion Matrix with Percentage Values
    plt.figure(figsize=(10, 8))
    plt.yticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
    plt.xticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
    plt.rcParams['font.sans-serif'] = "Times New Roman"
    plt.rcParams['font.size'] = 14
    plt.rcParams['font.weight'] = 'bold'
    ax = sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", xticklabels=class_names, yticklabels=class_names)
    # plt.rcParams['font.sans-serif'] = "Times New Roman"
    # plt.rcParams['font.size'] = 14
    # plt.rcParams['font.weight'] = 'bold'
    # plt.xticks(fontsize=14, fontweight="bold", fontname="Times New Roman")
    # plt.yticks(fontsize=14, fontweight="bold", fontname="Times New Roman")
    plt.xticks(rotation=0)

    # Annotate each cell with bold & Times New Roman font
    for text in ax.texts:
        text.set_fontsize(14)
        text.set_fontweight("bold")
        text.set_fontname("Times New Roman")
    plt.xlabel("Predicted Label", fontsize=14, fontweight="bold", fontfamily="Times New Roman")
    plt.ylabel("True Label", fontsize=14, fontweight="bold", fontfamily="Times New Roman")

    plt.title("Proposed DEPBS-TCNN : Confusion Matrix for multi-class setting", fontsize=14, fontweight="bold",
              fontfamily="Times New Roman")
    plt.tight_layout()
    plt.savefig("Graphs\\mccm_SipakMed Dataset.png")
    plt.close()
# Confusion_Matrix()

def MELD_CM():
    import numpy as np
    import matplotlib.pyplot as plt
    import seaborn as sns

    # ============================================================
    # Sample multiclass confusion matrix (%)
    # ============================================================

    cm_percentage = np.array([
        [98.50, 0.40, 0.30, 0.20, 0.60, 0.12, 0.03],
        [0.30, 99.10, 0.20, 0.10, 0.30, 0.11, 0.04],
        [0.40, 0.20, 98.70, 0.30, 0.40, 0.21, 0.03],
        [0.20, 0.10, 0.30, 99.00, 0.45, 0.03, 0.07],
        [0.50, 0.24, 0.30, 0.20, 98.80, 0.14, 0.11],
        [0.23, 0.08, 0.27, 0.21, 0.12,  97.45, 0.32],
        [0.17, 0.16, 0.03, 0.04, 0.37, 0.14, 99.34]
    ])

    class_names = [
        "Neutral", "Joy", "Sadness", "Anger", "Surprise", "Fear", "Disgust"
    ]

    # ============================================================
    # Create percentage annotations
    # ============================================================

    annotations = np.empty_like(cm_percentage, dtype=object)

    for i in range(cm_percentage.shape[0]):
        for j in range(cm_percentage.shape[1]):
            annotations[i, j] = f"{cm_percentage[i, j]:.2f}%"

    # ============================================================
    # Plot
    # ============================================================

    plt.figure(figsize=(10, 8))
    plt.rcParams['font.sans-serif'] = "Times New Roman"
    plt.rcParams['font.size'] = 14
    plt.rcParams['font.weight'] = 'bold'
    plt.xticks(fontsize=14, fontweight="bold", fontname="Times New Roman")
    plt.yticks(fontsize=14, fontweight="bold", fontname="Times New Roman")
    sns.heatmap(
        cm_percentage,
        annot=annotations,
        fmt="",
        cmap="Blues",
        xticklabels=class_names,
        yticklabels=class_names,
        linewidths=0.5,
        linecolor="black",
        vmin=0,
        vmax=100
    )

    plt.xlabel(
        "Predicted Class",
        fontsize=14,
        fontweight="bold"
    )

    plt.ylabel(
        "Actual Class",
        fontsize=14,
        fontweight="bold"
    )

    plt.title(
        "Confusion Matrix for MELD Dataset",
        fontsize=16,
        fontweight="bold"
    )

    plt.xticks(
        fontsize=11,
        fontweight="bold",
        rotation=45
    )

    plt.yticks(
        fontsize=11,
        fontweight="bold",
        rotation=0
    )

    plt.tight_layout()

    plt.savefig(
        "MELD_CM.png",
        bbox_inches="tight"
    )
    plt.close()
# MELD_CM()

def IEMOCAP_CM():
    import numpy as np
    import matplotlib.pyplot as plt
    import seaborn as sns

    # ============================================================
    # Sample multiclass confusion matrix (%)
    # ============================================================

    cm_percentage = np.array([
        [99.12, 0.24, 0.01, 0.12, 0.20, 0.41, 0.32, 0.02, 0.27, 0.52],
        [0.21, 99.03, 0.41, 0.35, 0.21, 0.43, 0.65, 0.26, 0.63, 0.02],
        [0.32, 0.20, 98.23, 0.27, 0.35, 0.34, 0.09, 0.04, 0.12, 0.16],
        [0.26, 0.74, 0.12, 99.24, 0.21, 0.04, 0.12, 0.03, 0.24, 0.36],
        [0.31, 0.17, 0.26, 0.31, 98.74, 0.06, 0.21, 0.03, 0.07, 0.01],
        [0.16, 0.13, 0.26, 0.41, 0.76,  98.69, 0.41, 0.06, 0.09, 0.07],
        [0.48, 0.32, 0.19, 0.27, 0.63, 0.17, 99.02, 0.07, 0.06, 0.14],
        [0.31, 0.41, 0.26, 0.61, 0.74, 0.32, 0.34, 99.02, 0.29, 0.61],
        [0.89, 0.63, 0.24, 0.46, 0.23, 0.61, 0.19, 0.32, 99.16, 0.21],
        [0.34, 0.46, 0.27, 0.19, 0.62, 0.27, 0.37, 0.03, 0.67, 99.46]
    ])

    class_names = [
        "Neutral", "Happiness", "Sadness", "Anger", "Surprise", "Fear", "Disgust", "Excited", "Frustration", "Other"
    ]

    # ============================================================
    # Create percentage annotations
    # ============================================================

    annotations = np.empty_like(cm_percentage, dtype=object)

    for i in range(cm_percentage.shape[0]):
        for j in range(cm_percentage.shape[1]):
            annotations[i, j] = f"{cm_percentage[i, j]:.2f}%"

    # ============================================================
    # Plot
    # ============================================================

    plt.figure(figsize=(10, 8))
    plt.rcParams['font.sans-serif'] = "Times New Roman"
    plt.rcParams['font.size'] = 14
    plt.rcParams['font.weight'] = 'bold'
    plt.xticks(fontsize=14, fontweight="bold", fontname="Times New Roman")
    plt.yticks(fontsize=14, fontweight="bold", fontname="Times New Roman")
    sns.heatmap(
        cm_percentage,
        annot=annotations,
        fmt="",
        cmap="Blues",
        xticklabels=class_names,
        yticklabels=class_names,
        linewidths=0.5,
        linecolor="black",
        vmin=0,
        vmax=100
    )

    plt.xlabel(
        "Predicted Class",
        fontsize=14,
        fontweight="bold"
    )

    plt.ylabel(
        "Actual Class",
        fontsize=14,
        fontweight="bold"
    )

    plt.title(
        "Confusion Matrix for IEMOCAP Dataset",
        fontsize=16,
        fontweight="bold"
    )

    plt.xticks(
        fontsize=11,
        fontweight="bold",
        rotation=45
    )

    plt.yticks(
        fontsize=11,
        fontweight="bold",
        rotation=0
    )

    plt.tight_layout()

    plt.savefig(
        "IEMOCAP_CM.png",
        bbox_inches="tight"
    )
    plt.close()
# IEMOCAP_CM()

def MELD_Correlation():
    import numpy as np
    import pandas as pd
    import seaborn as sns
    import matplotlib.pyplot as plt

    # 1. Mocking the MELD Emotion Correlation structure
    # (Replace this with: df = pd.read_csv('meld_data.csv'))
    emotions = ["", "Neutral", "Joy", "Sadness", "Anger", "Surprise", "Fear", "Disgust", ""]
    np.random.seed(42)

    # Simulating data distribution mapping for the 7 MELD categories
    data = pd.DataFrame(
        np.random.randint(0, 5, size=(1000, len(emotions))),
        columns=emotions
    )

    # 2. Compute the Pearson correlation matrix
    corr_matrix = data.corr()

    # 3. Generate a mask for the upper triangle
    # np.triu returns the upper triangle array, which masks those cells out
    mask = np.triu(np.ones_like(corr_matrix, dtype=bool))

    # 4. Set up the matplotlib figure
    plt.figure(figsize=(8, 6))
    plt.rcParams['font.sans-serif'] = "Times New Roman"
    plt.rcParams['font.size'] = 14
    plt.rcParams['font.weight'] = 'bold'
    plt.xticks(fontsize=14, fontweight="bold", fontname="Times New Roman")
    plt.yticks(fontsize=14, fontweight="bold", fontname="Times New Roman")
    # 5. Draw the lower-triangular heatmap
    sns.heatmap(
        corr_matrix,
        mask=mask,
        cmap='coolwarm',  # Standard diverging palette for negative/positive correlations
        vmax=1.5,
        vmin=-1.5,
        center=0,
        annot=True,  # Displays correlation values inside the squares
        fmt=".2f",
        square=True,  # Forces cells to be square-shaped
        linewidths=.5,  # Divides cells cleanly
        cbar_kws={"shrink": .8, "label": "Correlation Coefficient"}
    )

    plt.title('Lower-Triangular Emotion Correlation Heatmap for MELD Dataset', fontsize=14, pad=20)
    plt.xticks(rotation=45, ha='right')
    plt.yticks(rotation=0)
    plt.savefig(
        "MELD_Correlation.png",
        bbox_inches="tight"
    )
    plt.close()
# MELD_Correlation()

def IEMOCAP_Correlation():
    import numpy as np
    import pandas as pd
    import seaborn as sns
    import matplotlib.pyplot as plt

    # 1. Mocking the MELD Emotion Correlation structure
    # (Replace this with: df = pd.read_csv('meld_data.csv'))
    emotions = ["", "Neutral", "Happiness", "Sadness", "Anger", "Surprise", "Fear", "Disgust", "Excited", "Frustration", "Other", ""]
    np.random.seed(42)

    # Simulating data distribution mapping for the 7 MELD categories
    data = pd.DataFrame(
        np.random.randint(0, 5, size=(1000, len(emotions))),
        columns=emotions
    )

    # 2. Compute the Pearson correlation matrix
    corr_matrix = data.corr()

    # 3. Generate a mask for the upper triangle
    # np.triu returns the upper triangle array, which masks those cells out
    mask = np.triu(np.ones_like(corr_matrix, dtype=bool))

    # 4. Set up the matplotlib figure
    plt.figure(figsize=(8, 6))

    # 5. Draw the lower-triangular heatmap
    sns.heatmap(
        corr_matrix,
        mask=mask,
        cmap='coolwarm',  # Standard diverging palette for negative/positive correlations
        vmax=1.5,
        vmin=-1.5,
        center=0,
        annot=True,  # Displays correlation values inside the squares
        fmt=".2f",
        square=True,  # Forces cells to be square-shaped
        linewidths=.5,  # Divides cells cleanly
        cbar_kws={"shrink": .8, "label": "Correlation Coefficient"}
    )

    plt.title('Lower-Triangular Emotion Correlation Heatmap for IEMOCAP Dataset', fontsize=14, pad=20)
    plt.xticks(rotation=45, ha='right')
    plt.yticks(rotation=0)
    plt.savefig(
        "IEMOCAP_Correlation.png",
        bbox_inches="tight"
    )
    plt.close()
# IEMOCAP_Correlation()

def MELD_Feature_Number():
    import numpy as np
    import matplotlib.pyplot as plt

    # ============================================================
    # RANDOM SEED
    # ============================================================
    np.random.seed(42)

    # ============================================================
    # FEATURE NUMBERS
    # ============================================================
    features = np.arange(1, 7)

    # Number of lines for each emotion
    n_lines = 10

    # ============================================================
    # SAMPLE DATA FOR 7 MELD EMOTION CLASSES
    # Values are illustrative sample values
    # ============================================================

    neutral = np.array([
        [-5, 8, 12, -5, 10, 4],
        [-8, 5, 15, -8, 12, 2],
        [0, 10, 8, -3, 15, 5],
        [-10, 6, 13, -7, 8, 3],
        [-4, 9, 10, -6, 11, 6],
        [-7, 12, 16, -4, 14, 1],
        [2, 7, 11, -9, 9, 4],
        [-6, 11, 14, -2, 13, 7],
        [-2, 6, 9, -5, 10, 3],
        [-9, 8, 12, -6, 12, 5]
    ])

    joy = np.array([
        [-5, 12, 18, 15, 20, 10],
        [-8, 15, 20, 18, 24, 12],
        [-2, 10, 16, 20, 22, 15],
        [-10, 14, 19, 17, 25, 8],
        [-4, 18, 21, 22, 20, 12],
        [-12, 11, 17, 15, 27, 10],
        [-6, 16, 23, 19, 24, 14],
        [-3, 13, 18, 21, 22, 11],
        [-9, 17, 20, 16, 26, 9],
        [-1, 12, 22, 18, 23, 13]
    ])

    sadness = np.array([
        [-15, 8, 15, -12, 22, 10],
        [-10, 12, 10, -18, 18, 8],
        [-18, 5, 17, -10, 25, 12],
        [-12, 15, 12, -15, 20, 7],
        [-20, 7, 10, -20, 15, 5],
        [-14, 10, 14, -17, 27, 14],
        [-16, 9, 18, -14, 21, 11],
        [-11, 13, 11, -19, 24, 9],
        [-17, 6, 16, -11, 19, 6],
        [-13, 11, 13, -16, 23, 13]
    ])

    anger = np.array([
        [10, 5, 8, -12, -18, 15],
        [5, 12, 4, -20, -10, 22],
        [-10, 8, 10, -25, -5, 12],
        [12, 6, 9, -15, -2, 18],
        [-5, 10, 5, -18, -15, 10],
        [8, -5, 12, -28, 3, 25],
        [-2, 5, 7, -22, -12, 16],
        [15, 9, 6, -10, 1, 20],
        [2, -8, 10, -16, -8, 14],
        [-8, 7, 4, -24, -18, 10]
    ])

    surprise = np.array([
        [5, 15, -5, 20, 25, 10],
        [8, 12, -8, 25, 30, 15],
        [2, 18, -2, 22, 28, 12],
        [10, 10, -10, 18, 26, 8],
        [6, 20, -5, 28, 32, 14],
        [4, 14, -12, 23, 27, 10],
        [12, 16, -3, 20, 29, 16],
        [7, 11, -7, 26, 25, 11],
        [3, 17, -4, 21, 31, 13],
        [9, 13, -9, 24, 28, 9]
    ])

    fear = np.array([
        [-8, 0, 8, -5, -12, -5],
        [-5, 4, 10, -8, -10, -3],
        [-10, 2, 15, -6, -15, -8],
        [0, 6, 12, -10, -8, 1],
        [-7, -2, 9, -4, -13, -5],
        [-12, 3, 17, -7, -16, -10],
        [-4, 1, 11, -5, -9, 0],
        [-9, 5, 13, -9, -12, -4],
        [-6, -1, 7, -6, -14, -7],
        [-11, 4, 14, -8, -11, -2]
    ])

    disgust = np.array([
        [-12, 5, 10, -15, -18, -8],
        [-8, 8, 13, -18, -15, -5],
        [-15, 4, 8, -12, -20, -10],
        [-10, 10, 15, -20, -17, -7],
        [-18, 6, 11, -16, -22, -9],
        [-5, 9, 14, -14, -16, -6],
        [-13, 3, 9, -19, -21, -11],
        [-9, 7, 12, -17, -19, -4],
        [-16, 5, 16, -13, -18, -8],
        [-7, 6, 10, -21, -15, -5]
    ])

    # ============================================================
    # STORE DATA
    # ============================================================

    emotion_data = {
        "Neutral": neutral,
        "Joy": joy,
        "Sadness": sadness,
        "Anger": anger,
        "Surprise": surprise,
        "Fear": fear,
        "Disgust": disgust
    }

    # ============================================================
    # COLORS
    # ============================================================

    emotion_colors = {
        "Neutral": "#808080",
        "Joy": "#2E8B57",
        "Sadness": "#4682B4",
        "Anger": "#D55E00",
        "Surprise": "#9370DB",
        "Fear": "#E6A817",
        "Disgust": "#8B5A2B"
    }

    # ============================================================
    # CREATE FIGURE
    # ============================================================

    fig, axes = plt.subplots(
        2,
        4,
        figsize=(18, 9)
    )
    fig.suptitle(
        "MELD Dataset",
        fontsize=24,
        fontweight="bold",
        y=0.98
    )
    # Flatten axes
    axes = axes.flatten()

    # ============================================================
    # PLOT FUNCTION
    # ============================================================

    def plot_emotion(ax, data, title, color):

        # Plot every sample as one line
        for row in data:
            ax.plot(
                features,
                row,
                color=color,
                linewidth=1.8,
                alpha=0.70
            )

        # --------------------------------------------------------
        # X AXIS
        # --------------------------------------------------------

        ax.set_xlim(0.6, 6.4)

        ax.set_xticks(features)

        ax.set_xlabel(
            "feature number",
            fontsize=14
        )

        # --------------------------------------------------------
        # Y AXIS
        # --------------------------------------------------------

        ax.set_ylim(-30, 40)

        ax.set_yticks(
            np.arange(-30, 41, 10)
        )

        ax.set_ylabel(
            "slopes",
            fontsize=14
        )

        # --------------------------------------------------------
        # GRID
        # --------------------------------------------------------

        ax.grid(
            True,
            which="both",
            linestyle="--",
            linewidth=0.6,
            alpha=0.35
        )

        # --------------------------------------------------------
        # TITLE INSIDE GRAPH
        # --------------------------------------------------------

        ax.text(
            3.0,
            27,
            title,
            fontsize=28,
            ha="center",
            va="center",
            fontweight="normal"
        )

        # --------------------------------------------------------
        # TICK SIZE
        # --------------------------------------------------------

        ax.tick_params(
            axis="both",
            labelsize=11
        )

        # --------------------------------------------------------
        # BORDER
        # --------------------------------------------------------

        for spine in ax.spines.values():
            spine.set_linewidth(1.0)
            spine.set_alpha(0.5)

    # ============================================================
    # PLOT ALL 7 EMOTIONS
    # ============================================================

    for i, (emotion, data) in enumerate(
            emotion_data.items()):
        plot_emotion(
            axes[i],
            data,
            emotion,
            emotion_colors[emotion]
        )

    # ============================================================
    # REMOVE UNUSED 8TH SUBPLOT
    # ============================================================

    axes[7].axis("off")

    # ============================================================
    # OVERALL FIGURE
    # ============================================================

    plt.tight_layout(
        pad=2.0,
        w_pad=2.0,
        h_pad=2.0
    )
    # ============================================================
    # SAVE FIGURE
    # ============================================================

    plt.savefig(
        "MELD_Emotion_Feature_Slope_Plot.png",
        bbox_inches="tight"
    )

    # ============================================================
    # DISPLAY
    # ============================================================

    plt.show()
MELD_Feature_Number()

def IEMOCAP_Feature_Number():
    import numpy as np
    import matplotlib.pyplot as plt

    # ============================================================
    # RANDOM SEED
    # ============================================================
    np.random.seed(42)

    # ============================================================
    # FEATURE NUMBERS
    # ============================================================
    features = np.arange(1, 7)

    # ============================================================
    # SAMPLE DATA
    # 10 samples/lines for each emotion
    # Values are illustrative
    # ============================================================

    neutral = np.array([
        [-5, 8, 12, -5, 10, 4],
        [-8, 5, 15, -8, 12, 2],
        [0, 10, 8, -3, 15, 5],
        [-10, 6, 13, -7, 8, 3],
        [-4, 9, 10, -6, 11, 6],
        [-7, 12, 16, -4, 14, 1],
        [2, 7, 11, -9, 9, 4],
        [-6, 11, 14, -2, 13, 7],
        [-2, 6, 9, -5, 10, 3],
        [-9, 8, 12, -6, 12, 5]
    ])

    happiness = np.array([
        [-5, 12, 18, 15, 20, 10],
        [-8, 15, 20, 18, 24, 12],
        [-2, 10, 16, 20, 22, 15],
        [-10, 14, 19, 17, 25, 8],
        [-4, 18, 21, 22, 20, 12],
        [-12, 11, 17, 15, 27, 10],
        [-6, 16, 23, 19, 24, 14],
        [-3, 13, 18, 21, 22, 11],
        [-9, 17, 20, 16, 26, 9],
        [-1, 12, 22, 18, 23, 13]
    ])

    sadness = np.array([
        [-15, 8, 15, -12, 22, 10],
        [-10, 12, 10, -18, 18, 8],
        [-18, 5, 17, -10, 25, 12],
        [-12, 15, 12, -15, 20, 7],
        [-20, 7, 10, -20, 15, 5],
        [-14, 10, 14, -17, 27, 14],
        [-16, 9, 18, -14, 21, 11],
        [-11, 13, 11, -19, 24, 9],
        [-17, 6, 16, -11, 19, 6],
        [-13, 11, 13, -16, 23, 13]
    ])

    anger = np.array([
        [10, 5, 8, -12, -18, 15],
        [5, 12, 4, -20, -10, 22],
        [-10, 8, 10, -25, -5, 12],
        [12, 6, 9, -15, -2, 18],
        [-5, 10, 5, -18, -15, 10],
        [8, -5, 12, -28, 3, 25],
        [-2, 5, 7, -22, -12, 16],
        [15, 9, 6, -10, 1, 20],
        [2, -8, 10, -16, -8, 14],
        [-8, 7, 4, -24, -18, 10]
    ])

    surprise = np.array([
        [5, 15, -5, 20, 25, 10],
        [8, 12, -8, 25, 30, 15],
        [2, 18, -2, 22, 28, 12],
        [10, 10, -10, 18, 26, 8],
        [6, 20, -5, 28, 32, 14],
        [4, 14, -12, 23, 27, 10],
        [12, 16, -3, 20, 29, 16],
        [7, 11, -7, 26, 25, 11],
        [3, 17, -4, 21, 31, 13],
        [9, 13, -9, 24, 28, 9]
    ])

    fear = np.array([
        [-8, 0, 8, -5, -12, -5],
        [-5, 4, 10, -8, -10, -3],
        [-10, 2, 15, -6, -15, -8],
        [0, 6, 12, -10, -8, 1],
        [-7, -2, 9, -4, -13, -5],
        [-12, 3, 17, -7, -16, -10],
        [-4, 1, 11, -5, -9, 0],
        [-9, 5, 13, -9, -12, -4],
        [-6, -1, 7, -6, -14, -7],
        [-11, 4, 14, -8, -11, -2]
    ])

    disgust = np.array([
        [-12, 5, 10, -15, -18, -8],
        [-8, 8, 13, -18, -15, -5],
        [-15, 4, 8, -12, -20, -10],
        [-10, 10, 15, -20, -17, -7],
        [-18, 6, 11, -16, -22, -9],
        [-5, 9, 14, -14, -16, -6],
        [-13, 3, 9, -19, -21, -11],
        [-9, 7, 12, -17, -19, -4],
        [-16, 5, 16, -13, -18, -8],
        [-7, 6, 10, -21, -15, -5]
    ])

    excited = np.array([
        [8, 15, 20, 18, 28, 12],
        [10, 18, 23, 22, 32, 15],
        [5, 12, 25, 20, 30, 18],
        [12, 16, 21, 25, 27, 14],
        [7, 20, 24, 23, 34, 17],
        [4, 14, 22, 19, 29, 13],
        [11, 17, 26, 21, 31, 19],
        [6, 13, 23, 24, 28, 16],
        [9, 19, 22, 20, 33, 14],
        [3, 16, 27, 22, 30, 18]
    ])

    frustration = np.array([
        [-15, 5, 12, -15, -10, -5],
        [-10, 8, 15, -20, -15, -8],
        [-20, 3, 10, -18, -12, -10],
        [-12, 10, 18, -22, -17, -6],
        [-18, 6, 14, -16, -14, -9],
        [-8, 4, 13, -25, -10, -7],
        [-22, 7, 16, -19, -18, -12],
        [-14, 9, 11, -21, -13, -5],
        [-17, 2, 17, -17, -16, -8],
        [-11, 6, 14, -23, -11, -6]
    ])

    other = np.array([
        [-2, 4, 8, -2, 6, 3],
        [-5, 7, 10, -5, 8, 1],
        [1, 3, 6, 0, 7, 4],
        [-7, 5, 12, -4, 5, 2],
        [-3, 9, 7, -3, 10, 5],
        [2, 6, 11, 1, 8, 3],
        [-4, 2, 9, -6, 6, 1],
        [-6, 8, 13, -1, 9, 4],
        [0, 5, 7, -2, 11, 2],
        [-8, 4, 10, -5, 7, 3]
    ])

    # ============================================================
    # EMOTION DATA
    # ============================================================

    emotion_data = {
        "Neutral": neutral,
        "Happiness": happiness,
        "Sadness": sadness,
        "Anger": anger,
        "Surprise": surprise,
        "Fear": fear,
        "Disgust": disgust,
        "Excited": excited,
        "Frustration": frustration,
        "Other": other
    }

    # ============================================================
    # COLORS
    # ============================================================

    emotion_colors = {
        "Neutral": "#808080",
        "Happiness": "#2E8B57",
        "Sadness": "#4682B4",
        "Anger": "#D55E00",
        "Surprise": "#9370DB",
        "Fear": "#E6A817",
        "Disgust": "#8B5A2B",
        "Excited": "#C2185B",
        "Frustration": "#7B1FA2",
        "Other": "#008B8B"
    }

    # ============================================================
    # CREATE 2 × 5 FIGURE
    # ============================================================

    fig, axes = plt.subplots(
        2,
        5,
        figsize=(22, 9)
    )

    axes = axes.flatten()

    # ============================================================
    # PLOT FUNCTION
    # ============================================================

    def plot_emotion(ax, data, title, color):

        # Plot each sample as a separate line
        for row in data:
            ax.plot(
                features,
                row,
                color=color,
                linewidth=1.8,
                alpha=0.70
            )

        # --------------------------------------------------------
        # X AXIS
        # --------------------------------------------------------

        ax.set_xlim(0.6, 6.4)
        ax.set_xticks(features)

        ax.set_xlabel(
            "feature number",
            fontsize=13
        )

        # --------------------------------------------------------
        # Y AXIS
        # --------------------------------------------------------

        ax.set_ylim(-30, 40)

        ax.set_yticks(
            np.arange(-30, 41, 10)
        )

        ax.set_ylabel(
            "slopes",
            fontsize=13
        )

        # --------------------------------------------------------
        # GRID
        # --------------------------------------------------------

        ax.grid(
            True,
            which="both",
            linestyle="--",
            linewidth=0.6,
            alpha=0.35
        )

        # --------------------------------------------------------
        # EMOTION TITLE
        # --------------------------------------------------------

        ax.text(
            3,
            27,
            title,
            fontsize=23,
            ha="center",
            va="center",
            fontweight="normal"
        )

        # --------------------------------------------------------
        # TICKS
        # --------------------------------------------------------

        ax.tick_params(
            axis="both",
            labelsize=10
        )

        # --------------------------------------------------------
        # BORDER
        # --------------------------------------------------------

        for spine in ax.spines.values():
            spine.set_linewidth(1.0)
            spine.set_alpha(0.5)

    # ============================================================
    # PLOT ALL 10 CLASSES
    # ============================================================

    for i, (emotion, data) in enumerate(
            emotion_data.items()):
        plot_emotion(
            axes[i],
            data,
            emotion,
            emotion_colors[emotion]
        )

    # ============================================================
    # COMMON TITLE
    # ============================================================

    fig.suptitle(
        "MELD Dataset",
        fontsize=26,
        fontweight="bold",
        y=0.98
    )

    # ============================================================
    # LAYOUT
    # ============================================================

    plt.tight_layout(
        rect=[0, 0, 1, 0.94],
        pad=1.5,
        w_pad=1.5,
        h_pad=2.0
    )

    # ============================================================
    # SAVE FIGURE
    # ============================================================

    plt.savefig(
        "IEMOCAP_Feature_Number.png",
        dpi=300,
        bbox_inches="tight"
    )

    # ============================================================
    # DISPLAY
    # ============================================================
IEMOCAP_Feature_Number()