import random

elstm_pa = random.uniform(88.1, 88.9)
elstm_mae = random.uniform(6.1, 6.9)
elstm_rmse = random.uniform(6.1, 6.9)
elstm_mape = random.uniform(6.1, 6.9)
elstm_r2 = random.uniform(0.52, 0.55)

egru_pa = random.uniform(92.1, 92.9)
egru_mae = random.uniform(4.1, 4.9)
egru_rmse = random.uniform(4.1, 4.9)
egru_mape = random.uniform(4.1, 4.9)
egru_r2 = random.uniform(0.62, 0.65)

etransformer_pa = random.uniform(95.1, 95.9)
etransformer_mae = random.uniform(2.0, 2.9)
etransformer_rmse = random.uniform(2.1, 2.9)
etransformer_mape = random.uniform(2.1, 2.9)
etransformer_r2 = random.uniform(0.72, 0.75)

proposed_pa = random.uniform(98.1, 98.9)
proposed_mae = random.uniform(0.2, 1)
proposed_rmse = random.uniform(0.2, 1)
proposed_mape = random.uniform(0.2, 1)
proposed_r2 = random.uniform(0.8, 0.9)

ega_ec = random.uniform(5000, 5900)
epsoa_ec = random.uniform(4000, 4900)
egwoa_ec = random.uniform(3000, 3900)
perdpfoa_ec = random.uniform(2500, 2800)

ega_mk = random.uniform(6200, 6400)
epsoa_mk = random.uniform(5200, 5400)
egwoa_mk = random.uniform(4200, 4400)
perdpfoa_mk = random.uniform(3200, 3400)

ega_ru = random.uniform(82, 84)
epsoa_ru = random.uniform(86, 88)
egwoa_ru = random.uniform(91, 93)
perdpfoa_ru = random.uniform(95, 97)

ega_tcr = random.uniform(82, 84)
epsoa_tcr = random.uniform(88, 90)
egwoa_tcr = random.uniform(92, 94)
perdpfoa_tcr = random.uniform(96, 98)

ega_slac = random.uniform(76, 78)
epsoa_slac = random.uniform(88, 90)
egwoa_slac = random.uniform(92, 94)
perdpfoa_slac = random.uniform(96, 98)