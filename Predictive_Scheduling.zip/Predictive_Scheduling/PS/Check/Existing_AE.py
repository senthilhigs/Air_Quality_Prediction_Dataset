import os
import numpy as np
import tensorflow as tf
import joblib
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense
from tensorflow.keras.optimizers import Adam
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler

class Existing_AE:

    def training(self):
        NORMAL_MODEL_FILES = [
            r"..\Decrypted_Model\LM1\PDGIIP_LM1_Decryption.h5",
            r"..\Decrypted_Model\LM2\PDGIIP_LM2_Decryption.h5",
            r"..\Decrypted_Model\LM3\PDGIIP_LM3_Decryption.h5"
        ]
        output_folder = r"..\Proactive_Threat_Detection_Model"
        os.makedirs(output_folder, exist_ok=True)
        autoencoder_path = os.path.join(output_folder, "new_Model.h5")
        scaler_path = os.path.join(output_folder, "ae_scaler.pkl")
        threshold_path = os.path.join(output_folder, "threshold.npy")
        max_length_path = os.path.join(output_folder, "max_length.npy")

        def extract_weights(model_path):
            with open(model_path, "rb") as file:
                binary_data = file.read()
            vector = np.frombuffer(
                binary_data,
                dtype=np.uint8
            ).astype(np.float32)

            MAX_FEATURES = 5000
            if len(vector) > MAX_FEATURES:
                vector = vector[:MAX_FEATURES]

            elif len(vector) < MAX_FEATURES:
                vector = np.pad(
                    vector,
                    (0, MAX_FEATURES - len(vector)),
                    mode='constant'
                )

            return vector

        model_vectors = []

        print("\nLoading Models")
        print("====================================")
        for file in NORMAL_MODEL_FILES:
            print("\nLoading :", file)
            if not os.path.exists(file):
                print("File Not Found")
                continue

            try:
                weights = extract_weights(file)
                print("Feature Length :", len(weights))
                model_vectors.append(weights)
                print("Loaded Successfully")

            except Exception as e:
                print("Error Loading :", file)
                print(e)

        if len(model_vectors) == 0:
            print("\nNo Valid Models Loaded")
            return

        model_vectors = np.array(
            model_vectors,
            dtype=np.float32
        )

        print("\nDataset Shape :", model_vectors.shape)

        scaler = MinMaxScaler()
        model_vectors = scaler.fit_transform(model_vectors)

        joblib.dump(scaler,scaler_path)

        X_train, X_test = train_test_split(model_vectors,test_size=0.2,random_state=42)

        input_dim = X_train.shape[1]
        input_layer = Input(shape=(input_dim,))

        encoder = Dense(64,activation='relu')(input_layer)
        encoder = Dense(32,activation='relu')(encoder)
        encoder = Dense(16,activation='relu')(encoder)

        decoder = Dense(32,activation='relu')(encoder)
        decoder = Dense(64,activation='relu')(decoder)

        decoder = Dense(input_dim,activation='sigmoid')(decoder)

        autoencoder = Model(inputs=input_layer,outputs=decoder)

        autoencoder.compile(optimizer=Adam(learning_rate=0.001),loss='mse')

        autoencoder.summary()

        print("\nTraining Autoencoder")
        print("====================================")

        autoencoder.fit(
            X_train,
            X_train,
            epochs=10,
            batch_size=1,
            validation_data=(X_test, X_test),
            shuffle=True,
            verbose=1
        )

        autoencoder.save(autoencoder_path)
        print("\nAutoencoder Saved Successfully")

        print("Saved Path :", autoencoder_path)

        reconstructed = autoencoder.predict(X_train)

        mse = np.mean(
            np.power(X_train - reconstructed, 2), axis=1
        )

        threshold = np.mean(mse) + 3 * np.std(mse)

        print("\nAnomaly Threshold :",threshold)

        np.save(threshold_path,threshold)

        np.save(max_length_path,input_dim)

    def detect_model(self, model_path):
            output_folder = r"..\Proactive_Threat_Detection_Model"
            scaler_path = os.path.join(output_folder, "ae_scaler.pkl")
            threshold_path = os.path.join(output_folder, "threshold.npy")
            autoencoder_path = os.path.join(output_folder, "new_Model.h5")

            def extract_weights(model_path):
                with open(model_path, "rb") as file:
                    binary_data = file.read()
                vector = np.frombuffer(
                    binary_data,
                    dtype=np.uint8
                ).astype(np.float32)

                MAX_FEATURES = 5000
                if len(vector) > MAX_FEATURES:
                    vector = vector[:MAX_FEATURES]

                elif len(vector) < MAX_FEATURES:
                    vector = np.pad(
                        vector,
                        (0, MAX_FEATURES - len(vector)),
                        mode='constant'
                    )

                return vector

            print("\nChecking Model")
            print("=================")

            scaler = joblib.load(
                scaler_path
            )

            threshold = np.load(
                threshold_path
            )

            autoencoder = tf.keras.models.load_model(
                autoencoder_path,
                compile=False
            )

            weights = extract_weights(
                model_path
            )

            weights = weights.reshape(
                1,
                -1
            )

            weights = scaler.transform(
                weights
            )

            reconstruction = autoencoder.predict(
                weights
            )

            reconstruction_error = np.mean(
                np.power(
                    weights - reconstruction,
                    2
                )
            )

            print(
                "\nReconstruction Error :",
                reconstruction_error
            )

            result = ""
            if reconstruction_error > threshold:
                result = "ANOMALY"
                print(
                    "\nModel Status : MALICIOUS / ANOMALY"
                )

            else:
                result = "NORMAL"
                print(
                    "\nModel Status : NORMAL / TRUSTED"
                )

            return result

eae = Existing_AE()
test_model = ""
if os.path.exists(test_model):
    eae.detect_model(test_model)
else:
    print("\nTest Model Not Found")

print("\nProcess Completed Successfully")