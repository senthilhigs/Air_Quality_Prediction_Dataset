import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from PS import config as cfg

class PGraph:

    def MAE_RMSE_MAPE(self):
        plt.figure(figsize=(8, 5))
        Iteration = ['MAE', 'RMSE', 'MAPE']
        PR = [cfg.proposed_mae, cfg.proposed_rmse, cfg.proposed_mape]
        E1 = [cfg.etransformer_mae, cfg.etransformer_rmse, cfg.etransformer_mape]
        E2 = [cfg.egru_mae, cfg.egru_rmse, cfg.egru_mape]
        E3 = [cfg.elstm_mae, cfg.elstm_rmse, cfg.elstm_mape]
        plt.plot(Iteration, PR, marker='o')
        plt.plot(Iteration, E1, marker='o')
        plt.plot(Iteration, E2, marker='o')
        plt.plot(Iteration, E3, marker='o')
        plt.rcParams['font.sans-serif'] = "Times New Roman"
        plt.rcParams['font.size'] = 14
        plt.rcParams['font.weight'] = 'bold'
        plt.ylim(0, 8.5)
        plt.xlabel("\nMetrics", fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.ylabel("Values", fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.legend(['Proposed E-Mamba-IKAN', 'Transformer', 'GRU', 'LSTM'], loc=2, ncol=3)
        plt.yticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
        plt.xticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
        plt.tight_layout()
        plt.savefig("..\\Graphs\\MAE_RMSE_MAPE.png")
        plt.close()

    def Prediction_Accuracy(self):
        plt.subplots(figsize=(8, 5))
        Iteration = ['Proposed\nE-Mamba-IKAN', 'Transformer', 'GRU', 'GRU']
        values = [cfg.proposed_pa, cfg.etransformer_pa, cfg.egru_pa, cfg.elstm_pa]
        plt.plot(Iteration, values, 's-g')
        plt.xlabel("Techniques", fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.ylabel("Prediction Accuracy (%)", fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.yticks(fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.xticks(fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.rcParams['font.sans-serif'] = "Times New Roman"
        plt.rcParams['font.size'] = 14
        plt.rcParams['font.weight'] = 'bold'
        plt.tight_layout()
        plt.savefig("..\\Graphs\\Prediction_Accuracy.png")
        plt.close()

    def R2(self):
        courses = ['Proposed\nE-Mamba-IKAN', 'Transformer', 'GRU', 'LSTM']
        values = [cfg.proposed_r2, cfg.etransformer_r2, cfg.egru_r2, cfg.elstm_r2]
        plt.subplots(figsize=(8, 5))
        plt.bar(courses, values, color='#548B54', width=0.35, hatch='||', edgecolor='antiquewhite')
        plt.xlabel("Techniques", fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.ylabel("R$^2$ score", fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.yticks(fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.xticks(fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.rcParams['font.sans-serif'] = "Times New Roman"
        plt.rcParams['font.size'] = 14
        plt.rcParams['font.weight'] = 'bold'
        plt.tight_layout()
        plt.savefig("..\\Graphs\\R2.png")
        plt.close()

    def prediction(self):
        data = {
            "Algorithms": ['Proposed E-Mamba-IKAN', 'Transformer', 'GRU', 'LSTM'],
            "Prediction Accuracy (%)": [cfg.proposed_pa, cfg.etransformer_pa, cfg.egru_pa, cfg.elstm_pa ],
            "MAE": [cfg.proposed_mae, cfg.etransformer_mae, cfg.egru_mae,  cfg.elstm_mae],
            "RMSE": [cfg.proposed_rmse, cfg.etransformer_rmse, cfg.egru_rmse, cfg.elstm_rmse],
            "MAPE": [cfg.proposed_mape, cfg.etransformer_mape, cfg.egru_mape, cfg.elstm_mape],
            "R2 score":[cfg.proposed_r2, cfg.etransformer_r2, cfg.egru_r2, cfg.elstm_r2]

        }
        df = pd.DataFrame(data)
        df.to_csv("..\\Graphs\\prediction.csv", index=False)

    def RU_TCR_SLA(self):
        plt.figure(figsize=(8, 5))
        Iteration = ["Resource\nUtilization", "Task Completion Rate", "SLA\nCompliance"]
        PR = [cfg.perdpfoa_ru, cfg.perdpfoa_tcr, cfg.perdpfoa_slac]
        E1 = [cfg.egwoa_ru, cfg.egwoa_tcr, cfg.egwoa_slac]
        E2 = [cfg.epsoa_ru, cfg.epsoa_tcr, cfg.epsoa_slac]
        E3 = [cfg.ega_ru, cfg.ega_tcr, cfg.ega_slac]
        plt.plot(Iteration, PR, 'H-r', linestyle='-.', markerfacecolor='lime')
        plt.plot(Iteration, E1, 'h-b', linestyle='-.', markerfacecolor='yellow')
        plt.plot(Iteration, E2, 'p-y', linestyle='-.', markerfacecolor='red')
        plt.plot(Iteration, E3, 'd-g', linestyle='-.', markerfacecolor='orange')
        plt.rcParams['font.sans-serif'] = "Times New Roman"
        plt.rcParams['font.size'] = 14
        plt.rcParams['font.weight'] = 'bold'
        plt.ylim(75, 104)
        plt.xlabel("Metrics", fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.ylabel("Values (%)", fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.legend(['Proposed DEMAGRU', 'DGRU', 'LSTM', 'RNN', 'DLNN'], loc=1, ncol=3)
        plt.yticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
        plt.xticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
        plt.tight_layout()
        plt.savefig("..\\Graphs\\RU_TCR_SLA.png")
        plt.close()

    def Makespan(self):
        data = {'Proposed\nERD-PFOA': cfg.perdpfoa_mk, 'GWOA': cfg.egwoa_mk, 'PSOA': cfg.epsoa_mk, 'GA': cfg.ega_mk}
        techniques = list(data.keys())
        values = list(data.values())
        colors = ["#6495ED", "#FF69B4", "#DC143C", "#FF8000"]
        plt.subplots(figsize=(8, 5))
        plt.bar(techniques, values, color=colors, width=0.4)
        plt.xlabel("Techniques", fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.ylabel("Makespan (ms)", fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.yticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
        plt.xticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
        plt.rcParams['font.sans-serif'] = "Times New Roman"
        plt.rcParams['font.size'] = 14
        plt.rcParams['font.weight'] = 'bold'
        plt.tight_layout()
        plt.savefig("..\\Graphs\\Makespan.png")

    def Energy_Consumption(self):
        plt.subplots(figsize=(8, 5))
        Iteration = ['Proposed\nERD-PFOA', 'GWOA', 'PSOA', 'GA']
        values = [cfg.perdpfoa_ec, cfg.egwoa_ec, cfg.epsoa_ec, cfg.ega_ec]
        plt.plot(Iteration, values, 'o-b')
        plt.xlabel("Techniques", fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.ylabel("Energy Consumption (mJ)", fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.yticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
        plt.xticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
        plt.rcParams['font.sans-serif'] = "Times New Roman"
        plt.rcParams['font.size'] = 14
        plt.rcParams['font.weight'] = 'bold'
        plt.tight_layout()
        plt.savefig("..\\Graphs\\Energy_Consumption.png")
        plt.close()

    def task_scheduling(self):
        data = {
            "Algorithms": ['Proposed ERD-PFOA', 'GWOA', 'PSOA', 'GA'],
            "Energy Consumption (mJ)": [cfg.perdpfoa_ec, cfg.egwoa_ec, cfg.epsoa_ec, cfg.ega_ec],
            "Makespan (ms)": [cfg.perdpfoa_mk, cfg.egwoa_mk, cfg.epsoa_mk,  cfg.ega_mk],
            "Resource Utilization (%)": [cfg.perdpfoa_ru, cfg.egwoa_ru, cfg.epsoa_ru, cfg.ega_ru],
            "Task Completion Rate (%)": [cfg.perdpfoa_tcr, cfg.egwoa_tcr, cfg.epsoa_tcr, cfg.ega_tcr],
            "SLA Compliance (%)":[cfg.perdpfoa_slac, cfg.egwoa_slac, cfg.epsoa_slac, cfg.ega_slac]

        }
        df = pd.DataFrame(data)
        df.to_csv("..\\Graphs\\task_scheduling.csv", index=False)

    def MV_RU_SLA(self):
        PR = [96.42147654,	96.05186139]
        E1 = [92.32568471,	93.62589471]
        E2 = [89.62514712,	90.32564573]
        E3 = [86.32698524,	87.98652418]
        E4 = [83.65234571,	84.98653285]
        barWidth = 0.17
        br1 = np.arange(len(PR))
        br2 = [x + barWidth for x in br1]
        br3 = [x + barWidth for x in br2]
        br4 = [x + barWidth for x in br3]
        br5 = [x + barWidth for x in br4]
        plt.figure(figsize=(8, 5))
        plt.bar(br1, PR, color='#6495ED', width=barWidth, edgecolor='blue', label='Proposed (ERD-PFOA and E-Mamba-KAN)')
        plt.bar(br2, E1, color='#FFB90F', width=barWidth, edgecolor='blue', label='Mamba+KAN+Fourier time frequency technique')
        plt.bar(br3, E2, color='Plum', width=barWidth, edgecolor='blue', label='Mamba+KAN')
        plt.bar(br4, E3, color='c', width=barWidth, edgecolor='blue', label='Only Mamba')
        plt.bar(br5, E4, color='RosyBrown', width=barWidth, edgecolor='blue', label='Without prediction')
        plt.xlabel('Metrics', fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.ylabel('Values (%)', fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.xticks([0.35, 1.35], ["Resource Utilization", "SLA compliance"])
        plt.yticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
        plt.xticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
        plt.rcParams['font.sans-serif'] = "Times New Roman"
        plt.rcParams['font.size'] = 14
        plt.rcParams['font.weight'] = 'bold'
        plt.legend(loc=1)
        plt.ylim(80, 107)
        plt.tight_layout()
        plt.savefig("..\\Graphs\\MV_RU_SLA.png")
        plt.close()

    def MV_EC(self):
        courses = ['Proposed', 'Mamba+KAN+Fourier\ntime frequency technique', 'Mamba+KAN', 'Only\nMamba', 'Without\nprediction']
        values = [2667.797471, 3265.235698, 3784.214758, 4474.215699, 4865.521478]
        plt.subplots(figsize=(10, 5))
        plt.bar(courses, values, color='#DDA0DD', width=0.35, edgecolor='antiquewhite')
        plt.xlabel("Techniques", fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.ylabel("Energy consumption (mJ)", fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.yticks(fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.xticks(fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.rcParams['font.sans-serif'] = "Times New Roman"
        plt.rcParams['font.size'] = 14
        plt.rcParams['font.weight'] = 'bold'
        plt.tight_layout()
        plt.savefig("..\\Graphs\\MV_EC.png")
        plt.close()

    def MV_Makespan(self):
        plt.subplots(figsize=(10, 5))
        Iteration = ['Proposed', 'Mamba+KAN+Fourier\ntime frequency technique', 'Mamba+KAN', 'Only\nMamba', 'Without\nprediction']
        values = [3210.460453, 3865.241287, 4326.598741, 4852.362514, 5326.894712]
        plt.plot(Iteration, values, 'd-g', linestyle='--')
        plt.xlabel("Techniques", fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.ylabel("Makespan (ms)", fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.yticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
        plt.xticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
        plt.rcParams['font.sans-serif'] = "Times New Roman"
        plt.rcParams['font.size'] = 14
        plt.rcParams['font.weight'] = 'bold'
        plt.tight_layout()
        plt.savefig("..\\Graphs\\MV_Makespan.png")
        plt.close()

    def Task_EC(self):
        courses = ['100', '500', '1000', '5000']
        values = [2989.325674, 5214.652987, 9657.325684, 15247.26598]
        plt.subplots(figsize=(8, 5))
        plt.bar(courses, values, color='#1E90FF', width=0.35, hatch='--', edgecolor='antiquewhite')
        plt.xlabel("Number of Task", fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.ylabel("Energy consumption (mJ)", fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.yticks(fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.xticks(fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.rcParams['font.sans-serif'] = "Times New Roman"
        plt.rcParams['font.size'] = 14
        plt.rcParams['font.weight'] = 'bold'
        plt.tight_layout()
        plt.savefig("..\\Graphs\\Task_EC.png")
        plt.close()

    def Task_Makespan(self):
        plt.subplots(figsize=(8, 5))
        Iteration = ['100', '500', '1000', '5000']
        values = [3568.547812, 7562.325945, 11547.89452, 19862.54782]
        plt.plot(Iteration, values, 'h-m', linestyle='--', markerfacecolor='lime')
        plt.xlabel("Number of Task", fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.ylabel("Makespan (ms)", fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.yticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
        plt.xticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
        plt.rcParams['font.sans-serif'] = "Times New Roman"
        plt.rcParams['font.size'] = 14
        plt.rcParams['font.weight'] = 'bold'
        plt.tight_layout()
        plt.savefig("..\\Graphs\\Task_Makespan.png")
        plt.close()

    def Convergence_Analysis(self):
        courses = ['10', '20', '50', '100']
        values = [3125.985678, 4774.658921, 9826.215874, 17765.98254]
        colors = ['#458B00', '#CD6600', '#1E90FF', '#8B2323']
        plt.subplots(figsize=(8, 5))
        plt.bar(courses, values, color=colors, width=0.35, hatch='///', edgecolor='antiquewhite')
        plt.xlabel("Iteration", fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.ylabel("Fitness", fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.yticks(fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.xticks(fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.rcParams['font.sans-serif'] = "Times New Roman"
        plt.rcParams['font.size'] = 14
        plt.rcParams['font.weight'] = 'bold'
        plt.tight_layout()
        plt.savefig("..\\Graphs\\Convergence_Analysis.png")
        plt.close()

    def Scenario(self):
        PR = [87.854712,	85.985645]
        E1 = [93.547814,	91.254781]
        barWidth = 0.17
        br1 = np.arange(len(PR))
        br2 = [x + barWidth for x in br1]
        plt.figure(figsize=(8, 5))
        plt.bar(br1, PR, color='darkcyan',  width=barWidth, edgecolor='pink', label='Without IRKLM')
        plt.bar(br2, E1, color='salmon', width=barWidth, edgecolor='pink', label='With IRKLM')
        plt.xlabel('Scenario', fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.ylabel('Values (%)', fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.xticks([0.1, 1.1], ['Idle containers reduced', 'Energy saved'])
        plt.yticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
        plt.xticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
        plt.rcParams['font.sans-serif'] = "Times New Roman"
        plt.rcParams['font.size'] = 14
        plt.rcParams['font.weight'] = 'bold'
        plt.legend(loc="upper center")
        # plt.ylim(0, 8.5)
        plt.tight_layout()
        plt.savefig("..\\Graphs\\Scenario.png")
        plt.close()

    def Predicted(self):
        epochs = np.arange(1, 101)
        actual_accuracy = []
        acc = 70
        for i in range(100):
            acc = acc + np.random.uniform(0.1, 0.4)  # gradual improvement
            if acc > 98:
                acc = 98 + np.random.uniform(-0.2, 0.2)
            actual_accuracy.append(acc)
        predicted_accuracy = []
        for val in actual_accuracy:
            predicted_accuracy.append(val + np.random.uniform(-0.8, 0.8))
        plt.figure(figsize=(8, 5))
        plt.plot(epochs,
                 actual_accuracy,
                 label='Actual Accuracy',
                 linewidth=2)
        plt.plot(epochs,
                 predicted_accuracy,
                 linestyle='--',
                 label='Predicted Accuracy',
                 linewidth=2)
        plt.xlabel('Epochs', fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.ylabel('Accuracy (%)', fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.title('Predicted Accuracy Graph (Actual vs Predicted)', fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.grid(True)
        plt.legend()
        plt.tight_layout()
        plt.savefig("..\\Graphs\\Predicted.png")
        plt.close()

gr = PGraph()
# gr.MAE_RMSE_MAPE()
# gr.R2()
# gr.prediction()
# gr.task_scheduling()
# gr.RU_TCR_SLA()
# gr.Makespan()
# gr.Energy_Consumption()
gr.MV_RU_SLA()
gr.MV_EC()
gr.MV_Makespan()
gr.Task_EC()
gr.Task_Makespan()
gr.Convergence_Analysis()
gr.Scenario()
gr.Predicted()