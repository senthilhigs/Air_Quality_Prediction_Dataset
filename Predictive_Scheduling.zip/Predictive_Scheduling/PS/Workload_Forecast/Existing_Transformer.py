"""
Workload Forecasting using Transformer Neural Network

Dataset Columns
---------------
Timestamp [ms]
CPU cores
CPU capacity provisioned [MHZ]
CPU usage [MHZ]
CPU usage [%]
Memory capacity provisioned [KB]
Memory usage [KB]
Disk read throughput [KB/s]
Disk write throughput [KB/s]
Network received throughput [KB/s]
Network transmitted throughput [KB/s]

Goal
----
Forecast workload using Transformer-based Deep Learning Model

Requirements
------------
pip install pandas numpy matplotlib scikit-learn tensorflow

Dataset
-------
Save dataset as:
workload.csv
"""
import os
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    mean_squared_error,
    mean_absolute_error,
    mean_absolute_percentage_error,
    r2_score
)

import tensorflow as tf

from tensorflow.keras.models import Model
from tensorflow.keras.layers import (
    Input,
    Dense,
    Dropout,
    LayerNormalization,
    MultiHeadAttention,
    GlobalAveragePooling1D
)

from tensorflow.keras.callbacks import EarlyStopping

class Existing_Transformer:
    def training(self):
        # ============================================================
        # 1. Load Dataset
        # ============================================================

        df = pd.read_csv("..\\Dataset\\Workload Forecasting Dataset.csv")

        print("\nDataset Preview:")
        print(df.head())


        # ============================================================
        # 2. Feature Selection
        # ============================================================

        features = [
            "CPU cores",
            "CPU capacity provisioned [MHZ]",
            "CPU usage [MHZ]",
            "CPU usage [%]",
            "Memory capacity provisioned [KB]",
            "Memory usage [KB]",
            "Disk read throughput [KB/s]",
            "Disk write throughput [KB/s]",
            "Network received throughput [KB/s]",
            "Network transmitted throughput [KB/s]"
        ]

        target_column = "CPU usage [%]"

        data = df[features].values


        # ============================================================
        # 3. Normalize Data
        # ============================================================

        scaler = MinMaxScaler()

        scaled_data = scaler.fit_transform(data)


        # ============================================================
        # 4. Create Sequences
        # ============================================================

        def create_sequences(data, target_index, sequence_length=10):

            X = []
            y = []

            for i in range(len(data) - sequence_length):

                X.append(
                    data[i:i + sequence_length]
                )

                y.append(
                    data[i + sequence_length][target_index]
                )

            return np.array(X), np.array(y)


        target_index = features.index(target_column)

        SEQUENCE_LENGTH = 10

        X, y = create_sequences(
            scaled_data,
            target_index,
            SEQUENCE_LENGTH
        )

        print("\nInput Shape :", X.shape)
        print("Target Shape:", y.shape)


        # ============================================================
        # 5. Train-Test Split
        # ============================================================

        X_train, X_test, y_train, y_test = train_test_split(
            X,
            y,
            test_size=0.2,
            shuffle=False
        )


        # ============================================================
        # 6. Transformer Encoder Block
        # ============================================================

        def transformer_encoder(inputs,
                                head_size,
                                num_heads,
                                ff_dim,
                                dropout=0):

            # Multi-Head Attention
            attention = MultiHeadAttention(
                key_dim=head_size,
                num_heads=num_heads,
                dropout=dropout
            )(inputs, inputs)

            attention = Dropout(dropout)(attention)

            attention = LayerNormalization(epsilon=1e-6)(
                attention + inputs
            )

            # Feed Forward Network
            ff = Dense(ff_dim, activation="relu")(attention)

            ff = Dropout(dropout)(ff)

            ff = Dense(inputs.shape[-1])(ff)

            ff = LayerNormalization(epsilon=1e-6)(
                ff + attention
            )

            return ff


        # ============================================================
        # 7. Build Transformer Model
        # ============================================================

        input_layer = Input(shape=(X.shape[1], X.shape[2]))

        x = transformer_encoder(
            input_layer,
            head_size=64,
            num_heads=4,
            ff_dim=128,
            dropout=0.2
        )

        x = transformer_encoder(
            x,
            head_size=64,
            num_heads=4,
            ff_dim=128,
            dropout=0.2
        )

        x = GlobalAveragePooling1D()(x)

        x = Dense(64, activation="relu")(x)

        x = Dropout(0.2)(x)

        output_layer = Dense(1)(x)

        model = Model(inputs=input_layer,
                      outputs=output_layer)

        model.compile(
            optimizer="adam",
            loss="mse",
            metrics=["mae"]
        )

        model.summary()


        # ============================================================
        # 8. Train Model
        # ============================================================

        early_stop = EarlyStopping(
            monitor="val_loss",
            patience=10,
            restore_best_weights=True
        )

        history = model.fit(
            X_train,
            y_train,
            epochs=50,
            batch_size=32,
            validation_split=0.1,
            callbacks=[early_stop],
            verbose=1
        )


        # ============================================================
        # 9. Predict Workload
        # ============================================================

        y_pred = model.predict(X_test)


        # ============================================================
        # 10. Evaluate Model
        # ============================================================

        mse = mean_squared_error(y_test, y_pred)
        rmse = np.sqrt(mse)
        mae = mean_absolute_error(y_test, y_pred)
        mape = mean_absolute_percentage_error(y_test, y_pred)
        r2 = r2_score(y_test, y_pred)

        # ============================================================
        # 11. Save Model
        # ============================================================

        model.save("..\\Models\\ETransformer.h5")

        print("\nModel saved successfully.")