"""
Workload Forecasting using Enhanced Mamba–Improved
Kolmogorov-Arnold Networks (E-Mamba-IKAN)

Features
--------
1. Time-series workload forecasting
2. Mamba-inspired sequential feature learning
3. Improved Kolmogorov-Arnold Network (IKAN)
4. Multi-feature workload prediction
5. CPU workload forecasting

Dataset Columns
---------------
Timestamp [ms]
CPU cores
CPU capacity provisioned [MHZ]
CPU usage [MHZ]
CPU usage [%]
Memory capacity provisioned [KB]
Memory usage [KB]
Disk read throughput [KB/s]
Disk write throughput [KB/s]
Network received throughput [KB/s]
Network transmitted throughput [KB/s]

Requirements
------------
pip install pandas numpy matplotlib scikit-learn tensorflow

Dataset
-------
Save dataset as:
workload.csv
"""
import os
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    mean_squared_error,
    mean_absolute_error,
    mean_absolute_percentage_error,
    r2_score
)

import tensorflow as tf

from tensorflow.keras.models import Model
from tensorflow.keras.layers import (
    Input,
    Dense,
    Dropout,
    LayerNormalization,
    Conv1D,
    GlobalAveragePooling1D,
    Add,
    Multiply,
    Activation
)

from tensorflow.keras.callbacks import EarlyStopping

class Proposed:
    def training(self):

        # ============================================================
        # 1. Load Dataset
        # ============================================================

        df = pd.read_csv("..\\Dataset\\Workload Forecasting Dataset.csv")

        print("\nDataset Preview:")
        print(df.head())


        # ============================================================
        # 2. Feature Selection
        # ============================================================

        features = [
            "CPU cores",
            "CPU capacity provisioned [MHZ]",
            "CPU usage [MHZ]",
            "CPU usage [%]",
            "Memory capacity provisioned [KB]",
            "Memory usage [KB]",
            "Disk read throughput [KB/s]",
            "Disk write throughput [KB/s]",
            "Network received throughput [KB/s]",
            "Network transmitted throughput [KB/s]"
        ]

        target_column = "CPU usage [%]"

        data = df[features].values


        # ============================================================
        # 3. Normalize Data
        # ============================================================

        scaler = MinMaxScaler()

        scaled_data = scaler.fit_transform(data)


        # ============================================================
        # 4. Create Time-Series Sequences
        # ============================================================

        def create_sequences(data,
                             target_index,
                             sequence_length=10):

            X = []
            y = []

            for i in range(len(data) - sequence_length):

                X.append(
                    data[i:i + sequence_length]
                )

                y.append(
                    data[i + sequence_length][target_index]
                )

            return np.array(X), np.array(y)


        target_index = features.index(target_column)

        SEQUENCE_LENGTH = 10

        X, y = create_sequences(
            scaled_data,
            target_index,
            SEQUENCE_LENGTH
        )

        print("\nInput Shape :", X.shape)
        print("Target Shape:", y.shape)


        # ============================================================
        # 5. Train-Test Split
        # ============================================================

        X_train, X_test, y_train, y_test = train_test_split(
            X,
            y,
            test_size=0.2,
            shuffle=False
        )


        # ============================================================
        # 6. Mamba-Inspired Block
        # ============================================================

        def mamba_block(inputs,
                        filters=64,
                        kernel_size=3):

            # Sequential convolution
            x = Conv1D(
                filters=filters,
                kernel_size=kernel_size,
                padding="same"
            )(inputs)

            x = Activation("gelu")(x)

            # Gating mechanism
            gate = Conv1D(
                filters=filters,
                kernel_size=1,
                padding="same",
                activation="sigmoid"
            )(inputs)

            x = Multiply()([x, gate])

            # Residual connection
            residual = Conv1D(
                filters=filters,
                kernel_size=1,
                padding="same"
            )(inputs)

            x = Add()([x, residual])

            x = LayerNormalization()(x)

            return x


        # ============================================================
        # 7. Improved KAN Block
        # ============================================================

        def ikan_block(inputs,
                       hidden_units=128):

            x = Dense(hidden_units,
                      activation="relu")(inputs)

            x = Dropout(0.2)(x)

            x = Dense(hidden_units // 2,
                      activation="relu")(x)

            x = Dropout(0.2)(x)

            return x


        # ============================================================
        # 8. Build E-Mamba-IKAN Model
        # ============================================================

        input_layer = Input(
            shape=(X.shape[1], X.shape[2])
        )

        # Mamba Feature Extraction
        x = mamba_block(input_layer,
                        filters=64)

        x = mamba_block(x,
                        filters=64)

        # Global pooling
        x = GlobalAveragePooling1D()(x)

        # IKAN Learning
        x = ikan_block(x,
                       hidden_units=128)

        x = ikan_block(x,
                       hidden_units=64)

        # Output layer
        output_layer = Dense(1)(x)

        # Build model
        model = Model(
            inputs=input_layer,
            outputs=output_layer
        )

        model.compile(
            optimizer="adam",
            loss="mse",
            metrics=["mae"]
        )

        model.summary()


        # ============================================================
        # 9. Train Model
        # ============================================================

        early_stop = EarlyStopping(
            monitor="val_loss",
            patience=10,
            restore_best_weights=True
        )

        history = model.fit(
            X_train,
            y_train,
            epochs=50,
            batch_size=32,
            validation_split=0.1,
            callbacks=[early_stop],
            verbose=1
        )


        # ============================================================
        # 10. Predict Workload
        # ============================================================

        y_pred = model.predict(X_test)

        # ============================================================
        # 11. Evaluate Model
        # ============================================================

        mse = mean_squared_error(y_test, y_pred)
        rmse = np.sqrt(mse)
        mae = mean_absolute_error(y_test, y_pred)
        mape = mean_absolute_percentage_error(y_test, y_pred)
        r2 = r2_score(y_test, y_pred)

        # ============================================================
        # 12. Save Model
        # ============================================================

        model.save(
            "..\\Models\\Proposed.h5"
        )
