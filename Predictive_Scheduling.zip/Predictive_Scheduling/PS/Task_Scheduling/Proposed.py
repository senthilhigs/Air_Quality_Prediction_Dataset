"""
Multi-objective Enhanced Raindrop + Pufferfish Optimization Algorithm
(ERD-PFOA) for Task Scheduling

Features
--------
1. Multi-objective optimization
   - Makespan minimization
   - Load balancing
   - Cost minimization

2. Hybrid ERD-PFOA optimizer
   - ERD phase  : exploration
   - PFOA phase : exploitation

3. Cloud/Fog/Edge task scheduling example

Requirements
------------
pip install numpy

Author
------
Educational research-oriented implementation
"""

import numpy as np
import random


# ============================================================
# Task Scheduling Problem
# ============================================================

class TaskSchedulingProblem:
    def __init__(self, tasks, vms):
        """
        tasks : list of task lengths
        vms   : list of VM processing powers
        """

        self.tasks = tasks
        self.vms = vms

        self.num_tasks = len(tasks)
        self.num_vms = len(vms)

    def decode_solution(self, solution):
        """
        Convert continuous vector to VM assignments
        """
        assignments = np.floor(solution).astype(int)
        assignments = np.clip(assignments, 0, self.num_vms - 1)
        return assignments

    def evaluate(self, solution):
        """
        Multi-objective fitness evaluation
        """

        assignments = self.decode_solution(solution)

        vm_times = np.zeros(self.num_vms)
        vm_loads = np.zeros(self.num_vms)

        total_cost = 0

        for task_id, vm_id in enumerate(assignments):

            task_length = self.tasks[task_id]
            vm_power = self.vms[vm_id]

            execution_time = task_length / vm_power

            vm_times[vm_id] += execution_time
            vm_loads[vm_id] += task_length

            # Artificial resource cost
            total_cost += execution_time * (vm_id + 1)

        # Objective 1: Makespan
        makespan = np.max(vm_times)

        # Objective 2: Load balancing
        load_balance = np.std(vm_loads)

        # Objective 3: Cost
        cost = total_cost

        return makespan, load_balance, cost

    def scalar_fitness(self, solution, weights=(0.5, 0.3, 0.2)):
        """
        Weighted multi-objective fitness
        """

        makespan, load_balance, cost = self.evaluate(solution)

        fitness = (
            weights[0] * makespan +
            weights[1] * load_balance +
            weights[2] * cost
        )

        return fitness


# ============================================================
# ERD-PFOA Optimizer
# ============================================================

class ERD_PFOA:
    def __init__(
        self,
        problem,
        population_size=30,
        max_iterations=100,
        lower_bound=0,
        upper_bound=None,
        inflation_probability=0.5,
        random_seed=42,
    ):

        random.seed(random_seed)
        np.random.seed(random_seed)

        self.problem = problem

        self.population_size = population_size
        self.max_iterations = max_iterations

        self.dimensions = problem.num_tasks

        self.lower_bound = lower_bound
        self.upper_bound = (
            upper_bound
            if upper_bound is not None
            else problem.num_vms - 1
        )

        self.inflation_probability = inflation_probability

        # Initialize population
        self.population = self.initialize_population()

        self.fitness = np.array([
            self.problem.scalar_fitness(agent)
            for agent in self.population
        ])

        best_index = np.argmin(self.fitness)

        self.best_solution = self.population[best_index].copy()
        self.best_fitness = self.fitness[best_index]

    # --------------------------------------------------------

    def initialize_population(self):

        return np.random.uniform(
            self.lower_bound,
            self.upper_bound,
            (self.population_size, self.dimensions)
        )

    # --------------------------------------------------------

    def apply_bounds(self, solution):

        return np.clip(
            solution,
            self.lower_bound,
            self.upper_bound
        )

    # ========================================================
    # Enhanced Raindrop Phase (Exploration)
    # ========================================================

    def raindrop_update(self, current):

        random_agent = self.population[
            np.random.randint(self.population_size)
        ]

        rainfall_factor = np.random.uniform(-1, 1, self.dimensions)

        new_solution = (
            current
            + rainfall_factor * (random_agent - current)
        )

        return self.apply_bounds(new_solution)

    # ========================================================
    # Pufferfish Phase (Exploitation)
    # ========================================================

    def pufferfish_update(self, current):

        bubble_factor = np.random.uniform(
            0,
            1,
            self.dimensions
        )

        new_solution = (
            current
            + bubble_factor * (self.best_solution - current)
        )

        # Small perturbation
        perturbation = np.random.normal(
            0,
            0.05,
            self.dimensions
        )

        new_solution += perturbation

        return self.apply_bounds(new_solution)

    # ========================================================

    def optimize(self):

        convergence = []

        for iteration in range(self.max_iterations):

            for i in range(self.population_size):

                current = self.population[i].copy()

                # Hybrid decision
                if np.random.rand() < self.inflation_probability:

                    # ERD exploration
                    candidate = self.raindrop_update(current)

                else:

                    # PFOA exploitation
                    candidate = self.pufferfish_update(current)

                candidate_fitness = (
                    self.problem.scalar_fitness(candidate)
                )

                # Greedy selection
                if candidate_fitness < self.fitness[i]:

                    self.population[i] = candidate
                    self.fitness[i] = candidate_fitness

                    # Update global best
                    if candidate_fitness < self.best_fitness:

                        self.best_solution = candidate.copy()
                        self.best_fitness = candidate_fitness

            convergence.append(self.best_fitness)

            print(
                f"Iteration {iteration+1}/{self.max_iterations} "
                f"| Best Fitness = {self.best_fitness:.4f}"
            )

        return (
            self.best_solution,
            self.best_fitness,
            convergence
        )
